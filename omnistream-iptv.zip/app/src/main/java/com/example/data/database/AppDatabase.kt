package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.database.dao.AppSettingsDao
import com.example.data.database.dao.ChannelDao
import com.example.data.database.dao.EpgDao
import com.example.data.database.dao.FavoriteDao
import com.example.data.database.dao.MovieDao
import com.example.data.database.dao.PlaylistDao
import com.example.data.database.dao.SeriesDao
import com.example.data.database.dao.WatchHistoryDao
import com.example.data.database.dao.XtreamDao
import com.example.data.database.entity.AppSettingsEntity
import com.example.data.database.entity.ChannelEntity
import com.example.data.database.entity.EpisodeEntity
import com.example.data.database.entity.EpgProgramEntity
import com.example.data.database.entity.EpgSourceEntity
import com.example.data.database.entity.FavoriteEntity
import com.example.data.database.entity.MovieEntity
import com.example.data.database.entity.PlaylistEntity
import com.example.data.database.entity.SeriesEntity
import com.example.data.database.entity.WatchHistoryEntity
import com.example.data.database.entity.XtreamAccountEntity

@Database(
    entities = [
        PlaylistEntity::class,
        ChannelEntity::class,
        MovieEntity::class,
        SeriesEntity::class,
        EpisodeEntity::class,
        FavoriteEntity::class,
        WatchHistoryEntity::class,
        XtreamAccountEntity::class,
        EpgSourceEntity::class,
        EpgProgramEntity::class,
        AppSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun channelDao(): ChannelDao
    abstract fun movieDao(): MovieDao
    abstract fun seriesDao(): SeriesDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun watchHistoryDao(): WatchHistoryDao
    abstract fun xtreamDao(): XtreamDao
    abstract fun epgDao(): EpgDao
    abstract fun appSettingsDao(): AppSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "omnistream_iptv.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
