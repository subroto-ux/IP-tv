package com.example.data.parser

import android.util.Xml
import com.example.data.database.entity.EpgProgramEntity
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class XmlTvParser {

    private val dateFormats = listOf(
        SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") },
        SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    )

    fun parse(inputStream: InputStream, maxPrograms: Int = 15000): List<EpgProgramEntity> {
        val programs = mutableListOf<EpgProgramEntity>()
        try {
            val parser = Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(inputStream, "UTF-8")

            var eventType = parser.eventType
            var currentChannelId: String? = null
            var currentStartEpoch = 0L
            var currentEndEpoch = 0L
            var currentTitle: String? = null
            var currentDesc: String? = null
            var currentCategory: String? = null

            while (eventType != XmlPullParser.END_DOCUMENT && programs.size < maxPrograms) {
                val tagName = parser.name
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        if (tagName.equals("programme", ignoreCase = true)) {
                            currentChannelId = parser.getAttributeValue(null, "channel")
                            val startStr = parser.getAttributeValue(null, "start")
                            val stopStr = parser.getAttributeValue(null, "stop")
                            currentStartEpoch = parseDateToEpoch(startStr)
                            currentEndEpoch = parseDateToEpoch(stopStr)
                            currentTitle = null
                            currentDesc = null
                            currentCategory = null
                        } else if (tagName.equals("title", ignoreCase = true)) {
                            currentTitle = parser.nextText()
                        } else if (tagName.equals("desc", ignoreCase = true)) {
                            currentDesc = parser.nextText()
                        } else if (tagName.equals("category", ignoreCase = true)) {
                            currentCategory = parser.nextText()
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (tagName.equals("programme", ignoreCase = true)) {
                            if (!currentChannelId.isNullOrBlank() && !currentTitle.isNullOrBlank()) {
                                programs.add(
                                    EpgProgramEntity(
                                        channelTvgId = currentChannelId,
                                        title = currentTitle,
                                        description = currentDesc,
                                        startEpochSec = currentStartEpoch,
                                        endEpochSec = currentEndEpoch,
                                        category = currentCategory
                                    )
                                )
                            }
                        }
                    }
                }
                eventType = parser.next()
            }
        } catch (_: Exception) {
            // Graceful return of whatever was successfully parsed
        }
        return programs
    }

    private fun parseDateToEpoch(dateStr: String?): Long {
        if (dateStr.isNullOrBlank()) return 0L
        val trimmed = dateStr.trim()
        for (format in dateFormats) {
            try {
                val date = format.parse(trimmed)
                if (date != null) {
                    return date.time / 1000L
                }
            } catch (_: Exception) {
            }
        }
        // Fallback: try parsing raw digits yyyyMMddHHmmss
        try {
            val digits = trimmed.takeWhile { it.isDigit() }
            if (digits.length >= 14) {
                val year = digits.substring(0, 4).toInt()
                val month = digits.substring(4, 6).toInt() - 1
                val day = digits.substring(6, 8).toInt()
                val hour = digits.substring(8, 10).toInt()
                val min = digits.substring(10, 12).toInt()
                val sec = digits.substring(12, 14).toInt()
                val cal = java.util.Calendar.getInstance(TimeZone.getTimeZone("UTC"))
                cal.set(year, month, day, hour, min, sec)
                return cal.timeInMillis / 1000L
            }
        } catch (_: Exception) {
        }
        return 0L
    }
}
