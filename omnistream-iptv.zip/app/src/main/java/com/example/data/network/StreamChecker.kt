package com.example.data.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class StreamCheckResult(
    val url: String,
    val isPlayable: Boolean,
    val httpCode: Int,
    val responseTimeMs: Long,
    val contentType: String?,
    val serverHeader: String?,
    val statusMessage: String
)

class StreamChecker {

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun checkStream(url: String, userAgent: String? = null, referer: String? = null): StreamCheckResult =
        withContext(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            try {
                val reqBuilder = Request.Builder()
                    .url(url)
                    .addHeader("User-Agent", userAgent ?: "OmniStream-IPTV-Player")

                if (!referer.isNullOrBlank()) {
                    reqBuilder.addHeader("Referer", referer)
                }

                // Range header to only fetch first few bytes without downloading whole stream
                reqBuilder.addHeader("Range", "bytes=0-1024")

                val request = reqBuilder.get().build()
                val response = client.newCall(request).execute()
                val latency = System.currentTimeMillis() - startTime
                val code = response.code
                val contentType = response.header("Content-Type")
                val server = response.header("Server")

                val isSuccess = response.isSuccessful || code == 206 || code == 200 || code == 302 || code == 301
                val isMediaContent = contentType?.let {
                    it.contains("video", ignoreCase = true) ||
                    it.contains("mpegurl", ignoreCase = true) ||
                    it.contains("octet-stream", ignoreCase = true) ||
                    it.contains("audio", ignoreCase = true) ||
                    it.contains("mp2t", ignoreCase = true)
                } ?: true

                val playable = isSuccess && isMediaContent
                val message = when {
                    code in 200..299 -> "Online (HTTP $code)"
                    code in 300..399 -> "Redirects to target (HTTP $code)"
                    code == 401 || code == 403 -> "Authentication required (HTTP $code)"
                    code == 404 -> "Stream not found / Offline (HTTP 404)"
                    code >= 500 -> "Server internal error (HTTP $code)"
                    else -> "Returned HTTP $code"
                }

                StreamCheckResult(
                    url = url,
                    isPlayable = playable,
                    httpCode = code,
                    responseTimeMs = latency,
                    contentType = contentType,
                    serverHeader = server,
                    statusMessage = message
                )
            } catch (e: Exception) {
                val latency = System.currentTimeMillis() - startTime
                StreamCheckResult(
                    url = url,
                    isPlayable = false,
                    httpCode = -1,
                    responseTimeMs = latency,
                    contentType = null,
                    serverHeader = null,
                    statusMessage = "Error: ${e.message ?: "Connection failed"}"
                )
            }
        }
}
