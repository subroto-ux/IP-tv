package com.example.data.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class XtreamAuthResponse(
    @Json(name = "user_info") val userInfo: XtreamUserInfo? = null,
    @Json(name = "server_info") val serverInfo: XtreamServerInfo? = null
)

@JsonClass(generateAdapter = true)
data class XtreamUserInfo(
    val username: String? = null,
    val status: String? = null,
    @Json(name = "exp_date") val expDate: String? = null,
    @Json(name = "is_trial") val isTrial: String? = null,
    @Json(name = "active_cons") val activeCons: String? = null,
    @Json(name = "max_connections") val maxConnections: String? = null,
    val message: String? = null,
    val auth: Int? = null
)

@JsonClass(generateAdapter = true)
data class XtreamServerInfo(
    val url: String? = null,
    val port: String? = null,
    @Json(name = "https_port") val httpsPort: String? = null,
    @Json(name = "server_protocol") val serverProtocol: String? = null,
    val timezone: String? = null
)

@JsonClass(generateAdapter = true)
data class XtreamCategory(
    @Json(name = "category_id") val categoryId: String? = null,
    @Json(name = "category_name") val categoryName: String? = null
)

@JsonClass(generateAdapter = true)
data class XtreamLiveStream(
    val num: Any? = null,
    val name: String? = null,
    @Json(name = "stream_id") val streamId: Any? = null,
    @Json(name = "stream_icon") val streamIcon: String? = null,
    @Json(name = "category_id") val categoryId: String? = null,
    @Json(name = "epg_channel_id") val epgChannelId: String? = null
)

@JsonClass(generateAdapter = true)
data class XtreamVodStream(
    val name: String? = null,
    @Json(name = "stream_id") val streamId: Any? = null,
    @Json(name = "stream_icon") val streamIcon: String? = null,
    @Json(name = "rating") val rating: Any? = null,
    @Json(name = "category_id") val categoryId: String? = null,
    @Json(name = "container_extension") val containerExtension: String? = "mp4"
)

@JsonClass(generateAdapter = true)
data class XtreamSeries(
    val name: String? = null,
    @Json(name = "series_id") val seriesId: Any? = null,
    val cover: String? = null,
    val plot: String? = null,
    val rating: Any? = null,
    @Json(name = "release_date") val releaseDate: String? = null,
    @Json(name = "category_id") val categoryId: String? = null
)

class XtreamClient {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private fun normalizeServerUrl(server: String): String {
        var s = server.trim()
        if (!s.startsWith("http://") && !s.startsWith("https://")) {
            s = "http://$s"
        }
        return s.removeSuffix("/")
    }

    suspend fun authenticate(server: String, user: String, pass: String): Result<XtreamAuthResponse> =
        withContext(Dispatchers.IO) {
            try {
                val base = normalizeServerUrl(server)
                val url = "$base/player_api.php?username=$user&password=$pass"
                val request = Request.Builder().url(url).build()
                val response = okHttpClient.newCall(request).execute()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("HTTP error ${response.code}"))
                }
                val body = response.body?.string() ?: return@withContext Result.failure(Exception("Empty body"))
                val adapter = moshi.adapter(XtreamAuthResponse::class.java)
                val authResult = adapter.fromJson(body)
                if (authResult?.userInfo?.auth == 0) {
                    return@withContext Result.failure(Exception("Invalid username or password"))
                }
                Result.success(authResult ?: XtreamAuthResponse())
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getLiveCategories(server: String, user: String, pass: String): List<XtreamCategory> =
        withContext(Dispatchers.IO) {
            try {
                val base = normalizeServerUrl(server)
                val url = "$base/player_api.php?username=$user&password=$pass&action=get_live_categories"
                val request = Request.Builder().url(url).build()
                val response = okHttpClient.newCall(request).execute()
                val body = response.body?.string() ?: return@withContext emptyList()
                val type = com.squareup.moshi.Types.newParameterizedType(List::class.java, XtreamCategory::class.java)
                val adapter = moshi.adapter<List<XtreamCategory>>(type)
                adapter.fromJson(body) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }

    suspend fun getLiveStreams(server: String, user: String, pass: String, categoryId: String? = null): List<XtreamLiveStream> =
        withContext(Dispatchers.IO) {
            try {
                val base = normalizeServerUrl(server)
                var url = "$base/player_api.php?username=$user&password=$pass&action=get_live_streams"
                if (!categoryId.isNullOrBlank()) {
                    url += "&category_id=$categoryId"
                }
                val request = Request.Builder().url(url).build()
                val response = okHttpClient.newCall(request).execute()
                val body = response.body?.string() ?: return@withContext emptyList()
                val type = com.squareup.moshi.Types.newParameterizedType(List::class.java, XtreamLiveStream::class.java)
                val adapter = moshi.adapter<List<XtreamLiveStream>>(type)
                adapter.fromJson(body) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }

    suspend fun getVodStreams(server: String, user: String, pass: String): List<XtreamVodStream> =
        withContext(Dispatchers.IO) {
            try {
                val base = normalizeServerUrl(server)
                val url = "$base/player_api.php?username=$user&password=$pass&action=get_vod_streams"
                val request = Request.Builder().url(url).build()
                val response = okHttpClient.newCall(request).execute()
                val body = response.body?.string() ?: return@withContext emptyList()
                val type = com.squareup.moshi.Types.newParameterizedType(List::class.java, XtreamVodStream::class.java)
                val adapter = moshi.adapter<List<XtreamVodStream>>(type)
                adapter.fromJson(body) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }

    suspend fun getSeries(server: String, user: String, pass: String): List<XtreamSeries> =
        withContext(Dispatchers.IO) {
            try {
                val base = normalizeServerUrl(server)
                val url = "$base/player_api.php?username=$user&password=$pass&action=get_series"
                val request = Request.Builder().url(url).build()
                val response = okHttpClient.newCall(request).execute()
                val body = response.body?.string() ?: return@withContext emptyList()
                val type = com.squareup.moshi.Types.newParameterizedType(List::class.java, XtreamSeries::class.java)
                val adapter = moshi.adapter<List<XtreamSeries>>(type)
                adapter.fromJson(body) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }

    fun buildLiveStreamUrl(server: String, user: String, pass: String, streamId: Any, ext: String = "ts"): String {
        val base = normalizeServerUrl(server)
        return "$base/live/$user/$pass/$streamId.$ext"
    }

    fun buildMovieStreamUrl(server: String, user: String, pass: String, streamId: Any, ext: String = "mp4"): String {
        val base = normalizeServerUrl(server)
        return "$base/movie/$user/$pass/$streamId.$ext"
    }

    fun buildSeriesStreamUrl(server: String, user: String, pass: String, streamId: Any, ext: String = "mp4"): String {
        val base = normalizeServerUrl(server)
        return "$base/series/$user/$pass/$streamId.$ext"
    }
}
