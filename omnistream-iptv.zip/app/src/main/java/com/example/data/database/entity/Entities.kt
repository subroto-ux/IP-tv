package com.example.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val sourceUrl: String,
    val sourceType: String, // "URL", "FILE", "GITHUB", "TEXT"
    val isActive: Boolean = true,
    val channelCount: Int = 0,
    val movieCount: Int = 0,
    val seriesCount: Int = 0,
    val lastUpdated: Long = System.currentTimeMillis(),
    val autoRefresh: Boolean = false,
    val refreshIntervalHours: Int = 24,
    val userAgent: String? = null,
    val referer: String? = null
)

@Entity(tableName = "channels")
data class ChannelEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val playlistId: Long,
    val streamUrl: String,
    val name: String,
    val logo: String? = null,
    val category: String = "General",
    val tvgId: String? = null,
    val tvgName: String? = null,
    val country: String? = null,
    val language: String? = null,
    val isFavorite: Boolean = false,
    val orderIndex: Int = 0,
    val userAgent: String? = null,
    val referer: String? = null
)

@Entity(tableName = "movies")
data class MovieEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val playlistId: Long,
    val streamUrl: String,
    val name: String,
    val poster: String? = null,
    val category: String = "Movies",
    val rating: String? = null,
    val year: String? = null,
    val isFavorite: Boolean = false
)

@Entity(tableName = "series")
data class SeriesEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val playlistId: Long,
    val xtreamSeriesId: Int = 0,
    val name: String,
    val poster: String? = null,
    val category: String = "Series",
    val rating: String? = null,
    val releaseDate: String? = null,
    val isFavorite: Boolean = false
)

@Entity(tableName = "episodes")
data class EpisodeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val seriesId: Long,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String,
    val streamUrl: String,
    val containerExtension: String = "mp4",
    val duration: String? = null
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val contentId: Long,
    val contentType: String, // "CHANNEL", "MOVIE", "SERIES"
    val title: String,
    val streamUrl: String,
    val logo: String? = null,
    val category: String? = null,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val contentId: Long,
    val contentType: String, // "CHANNEL", "MOVIE", "EPISODE"
    val title: String,
    val streamUrl: String,
    val logo: String? = null,
    val playlistName: String? = null,
    val playbackPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "xtream_accounts")
data class XtreamAccountEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val serverUrl: String,
    val username: String,
    val passwordEncrypted: String,
    val isActive: Boolean = true,
    val isDefault: Boolean = false,
    val expDate: String? = null,
    val status: String? = null,
    val maxConnections: String? = null,
    val activeCons: String? = null,
    val message: String? = null,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "epg_sources")
data class EpgSourceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val url: String,
    val isActive: Boolean = true,
    val lastUpdated: Long = System.currentTimeMillis(),
    val programCount: Int = 0
)

@Entity(tableName = "epg_programs")
data class EpgProgramEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val channelTvgId: String,
    val title: String,
    val description: String? = null,
    val startEpochSec: Long,
    val endEpochSec: Long,
    val category: String? = null
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val themeMode: String = "AMOLED", // "DARK", "LIGHT", "AMOLED"
    val autoRotate: Boolean = true,
    val keepScreenOn: Boolean = true,
    val autoReconnect: Boolean = true,
    val defaultAspectRatio: String = "FIT", // "FIT", "FILL", "ZOOM", "16:9", "4:3"
    val defaultPlayer: String = "INTERNAL", // "INTERNAL", "EXTERNAL"
    val removeDuplicates: Boolean = true,
    val channelSortOrder: String = "DEFAULT", // "DEFAULT", "A_Z", "Z_A"
    val epgTimeOffsetHours: Int = 0,
    val firstLaunchCompleted: Boolean = false
)
