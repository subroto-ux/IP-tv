package com.example.data.repository

import android.content.Context
import com.example.data.database.AppDatabase
import com.example.data.database.entity.AppSettingsEntity
import com.example.data.database.entity.ChannelEntity
import com.example.data.database.entity.EpisodeEntity
import com.example.data.database.entity.EpgProgramEntity
import com.example.data.database.entity.EpgSourceEntity
import com.example.data.database.entity.FavoriteEntity
import com.example.data.database.entity.MovieEntity
import com.example.data.database.entity.PlaylistEntity
import com.example.data.database.entity.SeriesEntity
import com.example.data.database.entity.WatchHistoryEntity
import com.example.data.database.entity.XtreamAccountEntity
import com.example.data.network.StreamChecker
import com.example.data.network.XtreamClient
import com.example.data.parser.M3UParser
import com.example.data.parser.ParsedPlaylistResult
import com.example.data.parser.XmlTvParser
import com.example.data.security.SecureStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

class IptvRepository(
    private val database: AppDatabase,
    private val context: Context
) {
    private val playlistDao = database.playlistDao()
    private val channelDao = database.channelDao()
    private val movieDao = database.movieDao()
    private val seriesDao = database.seriesDao()
    private val favoriteDao = database.favoriteDao()
    private val watchHistoryDao = database.watchHistoryDao()
    private val xtreamDao = database.xtreamDao()
    private val epgDao = database.epgDao()
    private val appSettingsDao = database.appSettingsDao()

    private val m3uParser = M3UParser()
    private val xmlTvParser = XmlTvParser()
    private val xtreamClient = XtreamClient()
    val streamChecker = StreamChecker()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // Playlists
    val allPlaylists: Flow<List<PlaylistEntity>> = playlistDao.getAllPlaylists()
    val activePlaylists: Flow<List<PlaylistEntity>> = playlistDao.getActivePlaylists()

    // Channels
    val activeChannels: Flow<List<ChannelEntity>> = channelDao.getActiveChannels()
    val categories: Flow<List<String>> = channelDao.getCategories()
    val countries: Flow<List<String>> = channelDao.getCountries()
    val languages: Flow<List<String>> = channelDao.getLanguages()

    // Movies & Series
    val activeMovies: Flow<List<MovieEntity>> = movieDao.getActiveMovies()
    val movieCategories: Flow<List<String>> = movieDao.getMovieCategories()
    val activeSeries: Flow<List<SeriesEntity>> = seriesDao.getActiveSeries()
    val seriesCategories: Flow<List<String>> = seriesDao.getSeriesCategories()

    // Favorites & History
    val allFavorites: Flow<List<FavoriteEntity>> = favoriteDao.getAllFavorites()
    val recentHistory: Flow<List<WatchHistoryEntity>> = watchHistoryDao.getRecentHistory()
    val continueWatching: Flow<List<WatchHistoryEntity>> = watchHistoryDao.getContinueWatching()

    // Xtream & EPG
    val allXtreamAccounts: Flow<List<XtreamAccountEntity>> = xtreamDao.getAllAccounts()
    val allEpgSources: Flow<List<EpgSourceEntity>> = epgDao.getAllEpgSources()
    val appSettings: Flow<AppSettingsEntity?> = appSettingsDao.getSettingsFlow()

    suspend fun getSettings(): AppSettingsEntity {
        return appSettingsDao.getSettings() ?: AppSettingsEntity().also {
            appSettingsDao.insertOrUpdate(it)
        }
    }

    suspend fun updateSettings(settings: AppSettingsEntity) {
        appSettingsDao.insertOrUpdate(settings)
    }

    suspend fun addPlaylistFromUrl(
        name: String,
        url: String,
        userAgent: String? = null,
        referer: String? = null
    ): Result<PlaylistEntity> = withContext(Dispatchers.IO) {
        try {
            val reqBuilder = Request.Builder().url(url)
            if (!userAgent.isNullOrBlank()) reqBuilder.addHeader("User-Agent", userAgent)
            if (!referer.isNullOrBlank()) reqBuilder.addHeader("Referer", referer)

            val response = okHttpClient.newCall(reqBuilder.build()).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP Error ${response.code}: ${response.message}"))
            }

            val bodyStream = response.body?.byteStream()
                ?: return@withContext Result.failure(Exception("Empty playlist body"))

            val playlist = PlaylistEntity(
                name = name.ifBlank { "Playlist ${System.currentTimeMillis() % 1000}" },
                sourceUrl = url,
                sourceType = "URL",
                isActive = true,
                userAgent = userAgent,
                referer = referer
            )
            val playlistId = playlistDao.insertPlaylist(playlist)

            val parseResult = m3uParser.parse(bodyStream, playlistId, removeDuplicates = true)

            channelDao.insertChannels(parseResult.channels)
            movieDao.insertMovies(parseResult.movies)

            val updated = playlist.copy(
                id = playlistId,
                channelCount = parseResult.channels.size,
                movieCount = parseResult.movies.size,
                lastUpdated = System.currentTimeMillis()
            )
            playlistDao.updatePlaylist(updated)
            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addPlaylistFromStream(
        name: String,
        inputStream: InputStream,
        sourceType: String = "FILE"
    ): Result<PlaylistEntity> = withContext(Dispatchers.IO) {
        try {
            val playlist = PlaylistEntity(
                name = name.ifBlank { "Imported Playlist" },
                sourceUrl = "local://$name",
                sourceType = sourceType,
                isActive = true
            )
            val playlistId = playlistDao.insertPlaylist(playlist)

            val parseResult = m3uParser.parse(inputStream, playlistId, removeDuplicates = true)

            channelDao.insertChannels(parseResult.channels)
            movieDao.insertMovies(parseResult.movies)

            val updated = playlist.copy(
                id = playlistId,
                channelCount = parseResult.channels.size,
                movieCount = parseResult.movies.size,
                lastUpdated = System.currentTimeMillis()
            )
            playlistDao.updatePlaylist(updated)
            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun refreshPlaylist(playlistId: Long): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val playlist = playlistDao.getPlaylistById(playlistId)
                ?: return@withContext Result.failure(Exception("Playlist not found"))

            if (playlist.sourceType != "URL" && !playlist.sourceUrl.startsWith("http")) {
                return@withContext Result.failure(Exception("Only remote URL playlists can be refreshed automatically"))
            }

            val reqBuilder = Request.Builder().url(playlist.sourceUrl)
            if (!playlist.userAgent.isNullOrBlank()) reqBuilder.addHeader("User-Agent", playlist.userAgent)
            if (!playlist.referer.isNullOrBlank()) reqBuilder.addHeader("Referer", playlist.referer)

            val response = okHttpClient.newCall(reqBuilder.build()).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Failed to refresh: HTTP ${response.code}"))
            }

            val bodyStream = response.body?.byteStream()
                ?: return@withContext Result.failure(Exception("Empty playlist response"))

            // Clear old items for this playlist
            channelDao.deleteChannelsByPlaylist(playlistId)
            movieDao.deleteMoviesByPlaylist(playlistId)

            val parseResult = m3uParser.parse(bodyStream, playlistId, removeDuplicates = true)
            channelDao.insertChannels(parseResult.channels)
            movieDao.insertMovies(parseResult.movies)

            val updated = playlist.copy(
                channelCount = parseResult.channels.size,
                movieCount = parseResult.movies.size,
                lastUpdated = System.currentTimeMillis()
            )
            playlistDao.updatePlaylist(updated)

            Result.success(parseResult.channels.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun setPlaylistActive(id: Long, isActive: Boolean) {
        playlistDao.setPlaylistActive(id, isActive)
    }

    suspend fun deletePlaylist(id: Long) = withContext(Dispatchers.IO) {
        channelDao.deleteChannelsByPlaylist(id)
        movieDao.deleteMoviesByPlaylist(id)
        seriesDao.deleteSeriesByPlaylist(id)
        playlistDao.deletePlaylist(id)
    }

    // Favorites
    suspend fun toggleChannelFavorite(channel: ChannelEntity) = withContext(Dispatchers.IO) {
        val newStatus = !channel.isFavorite
        channelDao.updateFavoriteStatus(channel.id, newStatus)
        if (newStatus) {
            favoriteDao.insertFavorite(
                FavoriteEntity(
                    contentId = channel.id,
                    contentType = "CHANNEL",
                    title = channel.name,
                    streamUrl = channel.streamUrl,
                    logo = channel.logo,
                    category = channel.category
                )
            )
        } else {
            favoriteDao.deleteFavorite(channel.id, "CHANNEL")
        }
    }

    suspend fun toggleMovieFavorite(movie: MovieEntity) = withContext(Dispatchers.IO) {
        val newStatus = !movie.isFavorite
        movieDao.updateFavoriteStatus(movie.id, newStatus)
        if (newStatus) {
            favoriteDao.insertFavorite(
                FavoriteEntity(
                    contentId = movie.id,
                    contentType = "MOVIE",
                    title = movie.name,
                    streamUrl = movie.streamUrl,
                    logo = movie.poster,
                    category = movie.category
                )
            )
        } else {
            favoriteDao.deleteFavorite(movie.id, "MOVIE")
        }
    }

    // Watch History
    suspend fun recordWatchProgress(
        contentId: Long,
        contentType: String,
        title: String,
        streamUrl: String,
        logo: String?,
        playlistName: String?,
        positionMs: Long,
        durationMs: Long
    ) = withContext(Dispatchers.IO) {
        watchHistoryDao.insertOrUpdateHistory(
            WatchHistoryEntity(
                contentId = contentId,
                contentType = contentType,
                title = title,
                streamUrl = streamUrl,
                logo = logo,
                playlistName = playlistName,
                playbackPositionMs = positionMs,
                durationMs = durationMs,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteHistoryItem(id: Long) = watchHistoryDao.deleteHistoryItem(id)
    suspend fun clearAllHistory() = watchHistoryDao.clearAllHistory()

    // Xtream Codes
    suspend fun testXtreamConnection(server: String, user: String, pass: String) =
        xtreamClient.authenticate(server, user, pass)

    suspend fun addXtreamAccount(
        name: String,
        server: String,
        user: String,
        pass: String
    ): Result<XtreamAccountEntity> = withContext(Dispatchers.IO) {
        val authRes = xtreamClient.authenticate(server, user, pass)
        if (authRes.isFailure) {
            return@withContext Result.failure(authRes.exceptionOrNull() ?: Exception("Login failed"))
        }
        val info = authRes.getOrNull()?.userInfo

        val encryptedPass = SecureStorage.encrypt(pass)
        val account = XtreamAccountEntity(
            name = name.ifBlank { "Xtream ($user)" },
            serverUrl = server,
            username = user,
            passwordEncrypted = encryptedPass,
            isActive = true,
            status = info?.status ?: "Active",
            expDate = info?.expDate,
            maxConnections = info?.maxConnections,
            activeCons = info?.activeCons,
            message = info?.message
        )
        val id = xtreamDao.insertAccount(account)
        val created = account.copy(id = id)

        // Sync streams as a playlist
        syncXtreamStreams(created, pass)

        Result.success(created)
    }

    suspend fun syncXtreamStreams(account: XtreamAccountEntity, rawPass: String? = null) = withContext(Dispatchers.IO) {
        val pass = rawPass ?: SecureStorage.decrypt(account.passwordEncrypted)
        val liveStreams = xtreamClient.getLiveStreams(account.serverUrl, account.username, pass)
        val vodStreams = xtreamClient.getVodStreams(account.serverUrl, account.username, pass)

        // Create or update corresponding playlist
        var playlist = playlistDao.getPlaylistByUrl("xtream://${account.id}")
        val playlistId = if (playlist == null) {
            val p = PlaylistEntity(
                name = account.name,
                sourceUrl = "xtream://${account.id}",
                sourceType = "XTREAM",
                isActive = true
            )
            playlistDao.insertPlaylist(p)
        } else {
            playlist.id
        }

        channelDao.deleteChannelsByPlaylist(playlistId)
        movieDao.deleteMoviesByPlaylist(playlistId)

        val channelEntities = liveStreams.mapIndexed { index, s ->
            val streamId = s.streamId ?: index
            ChannelEntity(
                playlistId = playlistId,
                streamUrl = xtreamClient.buildLiveStreamUrl(account.serverUrl, account.username, pass, streamId),
                name = s.name ?: "Stream $streamId",
                logo = s.streamIcon,
                category = "Xtream Live",
                tvgId = s.epgChannelId,
                orderIndex = index
            )
        }
        channelDao.insertChannels(channelEntities)

        val movieEntities = vodStreams.mapIndexed { index, v ->
            val streamId = v.streamId ?: index
            val ext = v.containerExtension ?: "mp4"
            MovieEntity(
                playlistId = playlistId,
                streamUrl = xtreamClient.buildMovieStreamUrl(account.serverUrl, account.username, pass, streamId, ext),
                name = v.name ?: "Movie $streamId",
                poster = v.streamIcon,
                category = "Xtream VOD"
            )
        }
        movieDao.insertMovies(movieEntities)

        playlistDao.updatePlaylist(
            PlaylistEntity(
                id = playlistId,
                name = account.name,
                sourceUrl = "xtream://${account.id}",
                sourceType = "XTREAM",
                channelCount = channelEntities.size,
                movieCount = movieEntities.size,
                lastUpdated = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteXtreamAccount(id: Long) = withContext(Dispatchers.IO) {
        val playlist = playlistDao.getPlaylistByUrl("xtream://$id")
        if (playlist != null) {
            deletePlaylist(playlist.id)
        }
        xtreamDao.deleteAccount(id)
    }

    // EPG
    suspend fun addEpgSource(name: String, url: String): Result<EpgSourceEntity> = withContext(Dispatchers.IO) {
        try {
            val source = EpgSourceEntity(
                name = name.ifBlank { "EPG Source" },
                url = url,
                isActive = true
            )
            val id = epgDao.insertEpgSource(source)
            val created = source.copy(id = id)
            refreshEpgSource(id)
            Result.success(created)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun refreshEpgSource(id: Long): Result<Int> = withContext(Dispatchers.IO) {
        try {
            // Find target source
            val sources = mutableListOf<EpgSourceEntity>()
            // Query source
            val p = database.openHelper.readableDatabase.query("SELECT * FROM epg_sources WHERE id = $id LIMIT 1")
            var sourceUrl = ""
            var sourceName = ""
            if (p.moveToFirst()) {
                val urlIdx = p.getColumnIndex("url")
                val nameIdx = p.getColumnIndex("name")
                if (urlIdx >= 0) sourceUrl = p.getString(urlIdx)
                if (nameIdx >= 0) sourceName = p.getString(nameIdx)
            }
            p.close()

            if (sourceUrl.isBlank()) {
                return@withContext Result.failure(Exception("EPG Source not found"))
            }

            val request = Request.Builder().url(sourceUrl).build()
            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("EPG HTTP error ${response.code}"))
            }

            val bodyStream = response.body?.byteStream()
                ?: return@withContext Result.failure(Exception("Empty EPG response"))

            val programs = xmlTvParser.parse(bodyStream)
            if (programs.isNotEmpty()) {
                epgDao.insertPrograms(programs)
            }

            epgDao.updateEpgSource(
                EpgSourceEntity(
                    id = id,
                    name = sourceName,
                    url = sourceUrl,
                    programCount = programs.size,
                    lastUpdated = System.currentTimeMillis()
                )
            )

            Result.success(programs.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCurrentProgram(tvgId: String): EpgProgramEntity? = withContext(Dispatchers.IO) {
        val nowSec = System.currentTimeMillis() / 1000L
        epgDao.getCurrentProgram(tvgId, nowSec)
    }

    suspend fun getUpcomingPrograms(tvgId: String): List<EpgProgramEntity> = withContext(Dispatchers.IO) {
        val nowSec = System.currentTimeMillis() / 1000L
        epgDao.getUpcomingPrograms(tvgId, nowSec)
    }

    // Fast M3U Raw string parsing for tools
    fun parseM3uRaw(rawContent: String): ParsedPlaylistResult {
        val inputStream = ByteArrayInputStream(rawContent.toByteArray(Charsets.UTF_8))
        return m3uParser.parse(inputStream, 0, removeDuplicates = false)
    }
}
