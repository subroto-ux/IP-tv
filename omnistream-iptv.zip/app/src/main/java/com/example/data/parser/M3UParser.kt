package com.example.data.parser

import com.example.data.database.entity.ChannelEntity
import com.example.data.database.entity.MovieEntity
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.regex.Pattern

data class ParsedPlaylistResult(
    val channels: List<ChannelEntity>,
    val movies: List<MovieEntity>,
    val totalEntries: Int,
    val duplicateCount: Int,
    val categories: Set<String>,
    val countries: Set<String>,
    val languages: Set<String>,
    val invalidLines: Int
)

class M3UParser {

    private val tagPattern = Pattern.compile("([a-zA-Z0-9_-]+)=\"([^\"]*)\"")

    fun parse(
        inputStream: InputStream,
        playlistId: Long,
        removeDuplicates: Boolean = false
    ): ParsedPlaylistResult {
        val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
        val channels = mutableListOf<ChannelEntity>()
        val movies = mutableListOf<MovieEntity>()
        val seenUrls = mutableSetOf<String>()
        val categories = mutableSetOf<String>()
        val countries = mutableSetOf<String>()
        val languages = mutableSetOf<String>()

        var currentExtInf: String? = null
        var totalEntries = 0
        var duplicateCount = 0
        var invalidLines = 0
        var lineIndex = 0

        reader.useLines { lines ->
            for (rawLine in lines) {
                val line = rawLine.trim()
                if (line.isEmpty()) continue

                if (line.startsWith("#EXTINF:", ignoreCase = true)) {
                    currentExtInf = line
                } else if (line.startsWith("#")) {
                    // Other comments or directives (e.g., #EXTVLCOPT, #EXTM3U)
                    continue
                } else if (line.startsWith("http://") || line.startsWith("https://") || line.startsWith("rtmp://") || line.startsWith("rtsp://") || line.startsWith("mms://")) {
                    // Valid stream URL line
                    totalEntries++
                    val streamUrl = line

                    if (seenUrls.contains(streamUrl)) {
                        duplicateCount++
                        if (removeDuplicates) {
                            currentExtInf = null
                            continue
                        }
                    }
                    seenUrls.add(streamUrl)

                    val channelData = parseExtInf(currentExtInf ?: "", lineIndex++)
                    val category = channelData.category.ifBlank { "General" }
                    categories.add(category)
                    channelData.country?.takeIf { it.isNotBlank() }?.let { countries.add(it) }
                    channelData.language?.takeIf { it.isNotBlank() }?.let { languages.add(it) }

                    val isVod = isLikelyVod(category, streamUrl)
                    if (isVod) {
                        movies.add(
                            MovieEntity(
                                playlistId = playlistId,
                                streamUrl = streamUrl,
                                name = channelData.name,
                                poster = channelData.logo,
                                category = category
                            )
                        )
                    } else {
                        channels.add(
                            ChannelEntity(
                                playlistId = playlistId,
                                streamUrl = streamUrl,
                                name = channelData.name,
                                logo = channelData.logo,
                                category = category,
                                tvgId = channelData.tvgId,
                                tvgName = channelData.tvgName,
                                country = channelData.country,
                                language = channelData.language,
                                orderIndex = channels.size
                            )
                        )
                    }
                    currentExtInf = null
                } else {
                    // Malformed or unknown line
                    invalidLines++
                }
            }
        }

        return ParsedPlaylistResult(
            channels = channels,
            movies = movies,
            totalEntries = totalEntries,
            duplicateCount = duplicateCount,
            categories = categories,
            countries = countries,
            languages = languages,
            invalidLines = invalidLines
        )
    }

    private fun isLikelyVod(category: String, url: String): Boolean {
        val lowerCat = category.lowercase()
        if (lowerCat.contains("movie") || lowerCat.contains("vod") || lowerCat.contains("cinema") || lowerCat.contains("film")) {
            return true
        }
        val lowerUrl = url.lowercase().split("?").first()
        return lowerUrl.endsWith(".mp4") || lowerUrl.endsWith(".mkv") || lowerUrl.endsWith(".avi")
    }

    private data class ExtInfData(
        val name: String,
        val logo: String?,
        val category: String,
        val tvgId: String?,
        val tvgName: String?,
        val country: String?,
        val language: String?
    )

    private fun parseExtInf(extInf: String, fallbackIndex: Int): ExtInfData {
        if (extInf.isBlank()) {
            return ExtInfData(
                name = "Channel $fallbackIndex",
                logo = null,
                category = "General",
                tvgId = null,
                tvgName = null,
                country = null,
                language = null
            )
        }

        var tvgId: String? = null
        var tvgName: String? = null
        var tvgLogo: String? = null
        var groupTitle: String? = null
        var tvgCountry: String? = null
        var tvgLanguage: String? = null

        val matcher = tagPattern.matcher(extInf)
        while (matcher.find()) {
            val key = matcher.group(1)?.lowercase() ?: continue
            val value = matcher.group(2)?.trim() ?: continue

            when (key) {
                "tvg-id" -> tvgId = value
                "tvg-name" -> tvgName = value
                "tvg-logo" -> tvgLogo = value
                "group-title" -> groupTitle = value
                "tvg-country" -> tvgCountry = value
                "tvg-language" -> tvgLanguage = value
            }
        }

        // The channel name is typically after the last comma
        val commaIndex = extInf.lastIndexOf(',')
        val parsedName = if (commaIndex != -1 && commaIndex < extInf.length - 1) {
            extInf.substring(commaIndex + 1).trim()
        } else {
            tvgName ?: "Channel $fallbackIndex"
        }

        val finalName = if (parsedName.isNotBlank()) parsedName else (tvgName ?: "Channel $fallbackIndex")

        return ExtInfData(
            name = finalName,
            logo = tvgLogo?.takeIf { it.isNotBlank() },
            category = groupTitle?.takeIf { it.isNotBlank() } ?: "General",
            tvgId = tvgId?.takeIf { it.isNotBlank() },
            tvgName = tvgName?.takeIf { it.isNotBlank() },
            country = tvgCountry?.takeIf { it.isNotBlank() },
            language = tvgLanguage?.takeIf { it.isNotBlank() }
        )
    }
}
