package com.example.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.database.entity.AppSettingsEntity
import com.example.data.database.entity.ChannelEntity
import com.example.data.database.entity.EpisodeEntity
import com.example.data.database.entity.EpgProgramEntity
import com.example.data.database.entity.EpgSourceEntity
import com.example.data.database.entity.FavoriteEntity
import com.example.data.database.entity.MovieEntity
import com.example.data.database.entity.PlaylistEntity
import com.example.data.database.entity.SeriesEntity
import com.example.data.database.entity.WatchHistoryEntity
import com.example.data.database.entity.XtreamAccountEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY id DESC")
    fun getAllPlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE isActive = 1")
    fun getActivePlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :id LIMIT 1")
    suspend fun getPlaylistById(id: Long): PlaylistEntity?

    @Query("SELECT * FROM playlists WHERE sourceUrl = :url LIMIT 1")
    suspend fun getPlaylistByUrl(url: String): PlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Update
    suspend fun updatePlaylist(playlist: PlaylistEntity)

    @Query("UPDATE playlists SET isActive = :isActive WHERE id = :id")
    suspend fun setPlaylistActive(id: Long, isActive: Boolean)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deletePlaylist(id: Long)
}

@Dao
interface ChannelDao {
    @Query("SELECT * FROM channels WHERE playlistId IN (SELECT id FROM playlists WHERE isActive = 1) ORDER BY orderIndex ASC")
    fun getActiveChannels(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE playlistId = :playlistId ORDER BY orderIndex ASC")
    fun getChannelsByPlaylist(playlistId: Long): Flow<List<ChannelEntity>>

    @Query("SELECT DISTINCT category FROM channels WHERE playlistId IN (SELECT id FROM playlists WHERE isActive = 1) ORDER BY category ASC")
    fun getCategories(): Flow<List<String>>

    @Query("SELECT DISTINCT country FROM channels WHERE country IS NOT NULL AND country != '' AND playlistId IN (SELECT id FROM playlists WHERE isActive = 1) ORDER BY country ASC")
    fun getCountries(): Flow<List<String>>

    @Query("SELECT DISTINCT language FROM channels WHERE language IS NOT NULL AND language != '' AND playlistId IN (SELECT id FROM playlists WHERE isActive = 1) ORDER BY language ASC")
    fun getLanguages(): Flow<List<String>>

    @Query("SELECT * FROM channels WHERE id = :id LIMIT 1")
    suspend fun getChannelById(id: Long): ChannelEntity?

    @Query("SELECT COUNT(*) FROM channels WHERE playlistId = :playlistId")
    suspend fun getChannelCountForPlaylist(playlistId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannels(channels: List<ChannelEntity>)

    @Query("UPDATE channels SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteStatus(id: Long, isFavorite: Boolean)

    @Query("DELETE FROM channels WHERE playlistId = :playlistId")
    suspend fun deleteChannelsByPlaylist(playlistId: Long)
}

@Dao
interface MovieDao {
    @Query("SELECT * FROM movies WHERE playlistId IN (SELECT id FROM playlists WHERE isActive = 1) ORDER BY id DESC")
    fun getActiveMovies(): Flow<List<MovieEntity>>

    @Query("SELECT DISTINCT category FROM movies WHERE playlistId IN (SELECT id FROM playlists WHERE isActive = 1) ORDER BY category ASC")
    fun getMovieCategories(): Flow<List<String>>

    @Query("SELECT * FROM movies WHERE id = :id LIMIT 1")
    suspend fun getMovieById(id: Long): MovieEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovies(movies: List<MovieEntity>)

    @Query("UPDATE movies SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteStatus(id: Long, isFavorite: Boolean)

    @Query("DELETE FROM movies WHERE playlistId = :playlistId")
    suspend fun deleteMoviesByPlaylist(playlistId: Long)
}

@Dao
interface SeriesDao {
    @Query("SELECT * FROM series WHERE playlistId IN (SELECT id FROM playlists WHERE isActive = 1) ORDER BY id DESC")
    fun getActiveSeries(): Flow<List<SeriesEntity>>

    @Query("SELECT DISTINCT category FROM series WHERE playlistId IN (SELECT id FROM playlists WHERE isActive = 1) ORDER BY category ASC")
    fun getSeriesCategories(): Flow<List<String>>

    @Query("SELECT * FROM series WHERE id = :id LIMIT 1")
    suspend fun getSeriesById(id: Long): SeriesEntity?

    @Query("SELECT * FROM episodes WHERE seriesId = :seriesId ORDER BY seasonNumber ASC, episodeNumber ASC")
    fun getEpisodesForSeries(seriesId: Long): Flow<List<EpisodeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSeries(seriesList: List<SeriesEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisodes(episodes: List<EpisodeEntity>)

    @Query("UPDATE series SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteStatus(id: Long, isFavorite: Boolean)

    @Query("DELETE FROM series WHERE playlistId = :playlistId")
    suspend fun deleteSeriesByPlaylist(playlistId: Long)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY addedAt DESC")
    fun getAllFavorites(): Flow<List<FavoriteEntity>>

    @Query("SELECT * FROM favorites WHERE contentType = :type ORDER BY addedAt DESC")
    fun getFavoritesByType(type: String): Flow<List<FavoriteEntity>>

    @Query("SELECT * FROM favorites WHERE contentId = :contentId AND contentType = :type LIMIT 1")
    suspend fun getFavorite(contentId: Long, type: String): FavoriteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE contentId = :contentId AND contentType = :type")
    suspend fun deleteFavorite(contentId: Long, type: String)
}

@Dao
interface WatchHistoryDao {
    @Query("SELECT * FROM watch_history ORDER BY timestamp DESC LIMIT 50")
    fun getRecentHistory(): Flow<List<WatchHistoryEntity>>

    @Query("SELECT * FROM watch_history WHERE playbackPositionMs > 0 ORDER BY timestamp DESC LIMIT 20")
    fun getContinueWatching(): Flow<List<WatchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateHistory(item: WatchHistoryEntity)

    @Query("DELETE FROM watch_history WHERE id = :id")
    suspend fun deleteHistoryItem(id: Long)

    @Query("DELETE FROM watch_history")
    suspend fun clearAllHistory()
}

@Dao
interface XtreamDao {
    @Query("SELECT * FROM xtream_accounts ORDER BY id DESC")
    fun getAllAccounts(): Flow<List<XtreamAccountEntity>>

    @Query("SELECT * FROM xtream_accounts WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefaultAccount(): XtreamAccountEntity?

    @Query("SELECT * FROM xtream_accounts WHERE id = :id LIMIT 1")
    suspend fun getAccountById(id: Long): XtreamAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: XtreamAccountEntity): Long

    @Update
    suspend fun updateAccount(account: XtreamAccountEntity)

    @Query("UPDATE xtream_accounts SET isDefault = 0")
    suspend fun clearDefaultAccounts()

    @Query("UPDATE xtream_accounts SET isDefault = 1 WHERE id = :id")
    suspend fun setDefaultAccount(id: Long)

    @Query("DELETE FROM xtream_accounts WHERE id = :id")
    suspend fun deleteAccount(id: Long)
}

@Dao
interface EpgDao {
    @Query("SELECT * FROM epg_sources ORDER BY id DESC")
    fun getAllEpgSources(): Flow<List<EpgSourceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpgSource(source: EpgSourceEntity): Long

    @Update
    suspend fun updateEpgSource(source: EpgSourceEntity)

    @Query("DELETE FROM epg_sources WHERE id = :id")
    suspend fun deleteEpgSource(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrograms(programs: List<EpgProgramEntity>)

    @Query("DELETE FROM epg_programs WHERE endEpochSec < :cutoffSec")
    suspend fun deleteOldPrograms(cutoffSec: Long)

    @Query("DELETE FROM epg_programs")
    suspend fun clearAllPrograms()

    @Query("SELECT * FROM epg_programs WHERE channelTvgId = :tvgId AND endEpochSec >= :nowSec ORDER BY startEpochSec ASC LIMIT 10")
    suspend fun getUpcomingPrograms(tvgId: String, nowSec: Long): List<EpgProgramEntity>

    @Query("SELECT * FROM epg_programs WHERE channelTvgId = :tvgId AND startEpochSec <= :nowSec AND endEpochSec >= :nowSec LIMIT 1")
    suspend fun getCurrentProgram(tvgId: String, nowSec: Long): EpgProgramEntity?
}

@Dao
interface AppSettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    fun getSettingsFlow(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettings(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: AppSettingsEntity)
}
