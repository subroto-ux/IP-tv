package com.example.data.network

import android.util.Base64
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GitHubRepo(
    val name: String,
    @Json(name = "full_name") val fullName: String,
    val private: Boolean = false,
    val description: String? = null,
    @Json(name = "default_branch") val defaultBranch: String = "main",
    @Json(name = "html_url") val htmlUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class GitHubBranch(
    val name: String
)

@JsonClass(generateAdapter = true)
data class GitHubContentItem(
    val name: String,
    val path: String,
    val sha: String? = null,
    val size: Long = 0,
    val type: String, // "file" or "dir"
    val content: String? = null,
    val encoding: String? = null,
    @Json(name = "download_url") val downloadUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class GitHubCommitPayload(
    val message: String,
    val content: String, // base64 encoded
    val branch: String,
    val sha: String? = null
)

@JsonClass(generateAdapter = true)
data class GitHubDeletePayload(
    val message: String,
    val sha: String,
    val branch: String
)

class GitHubService {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun buildRequest(url: String, token: String?): Request.Builder {
        val builder = Request.Builder()
            .url(url)
            .addHeader("Accept", "application/vnd.github.v3+json")
            .addHeader("User-Agent", "OmniStream-IPTV-Android")
        if (!token.isNullOrBlank()) {
            builder.addHeader("Authorization", "Bearer ${token.trim()}")
        }
        return builder
    }

    suspend fun getRepositories(username: String?, token: String?): Result<List<GitHubRepo>> =
        withContext(Dispatchers.IO) {
            try {
                val url = if (!token.isNullOrBlank()) {
                    "https://api.github.com/user/repos?per_page=100&sort=updated"
                } else if (!username.isNullOrBlank()) {
                    "https://api.github.com/users/$username/repos?per_page=100&sort=updated"
                } else {
                    return@withContext Result.failure(Exception("Provide either a username or personal access token"))
                }

                val request = buildRequest(url, token).get().build()
                val response = okHttpClient.newCall(request).execute()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("GitHub API error: ${response.code} ${response.message}"))
                }
                val body = response.body?.string() ?: return@withContext Result.success(emptyList())
                val listType = Types.newParameterizedType(List::class.java, GitHubRepo::class.java)
                val adapter = moshi.adapter<List<GitHubRepo>>(listType)
                val repos = adapter.fromJson(body) ?: emptyList()
                Result.success(repos)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getBranches(owner: String, repo: String, token: String?): Result<List<GitHubBranch>> =
        withContext(Dispatchers.IO) {
            try {
                val url = "https://api.github.com/repos/$owner/$repo/branches"
                val request = buildRequest(url, token).get().build()
                val response = okHttpClient.newCall(request).execute()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Failed to fetch branches: ${response.code}"))
                }
                val body = response.body?.string() ?: return@withContext Result.success(emptyList())
                val listType = Types.newParameterizedType(List::class.java, GitHubBranch::class.java)
                val adapter = moshi.adapter<List<GitHubBranch>>(listType)
                Result.success(adapter.fromJson(body) ?: emptyList())
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getContents(owner: String, repo: String, path: String, branch: String, token: String?): Result<List<GitHubContentItem>> =
        withContext(Dispatchers.IO) {
            try {
                val cleanPath = path.trim().removePrefix("/").removeSuffix("/")
                val url = "https://api.github.com/repos/$owner/$repo/contents/$cleanPath?ref=$branch"
                val request = buildRequest(url, token).get().build()
                val response = okHttpClient.newCall(request).execute()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Error loading path: ${response.code}"))
                }
                val body = response.body?.string() ?: return@withContext Result.success(emptyList())

                // Could be array of items or single item
                if (body.trim().startsWith("[")) {
                    val listType = Types.newParameterizedType(List::class.java, GitHubContentItem::class.java)
                    val adapter = moshi.adapter<List<GitHubContentItem>>(listType)
                    Result.success(adapter.fromJson(body) ?: emptyList())
                } else {
                    val adapter = moshi.adapter(GitHubContentItem::class.java)
                    val single = adapter.fromJson(body)
                    Result.success(if (single != null) listOf(single) else emptyList())
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getFileContent(owner: String, repo: String, path: String, branch: String, token: String?): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val cleanPath = path.trim().removePrefix("/")
                val url = "https://api.github.com/repos/$owner/$repo/contents/$cleanPath?ref=$branch"
                val request = buildRequest(url, token).get().build()
                val response = okHttpClient.newCall(request).execute()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Error reading file: ${response.code}"))
                }
                val body = response.body?.string() ?: return@withContext Result.failure(Exception("Empty response"))
                val adapter = moshi.adapter(GitHubContentItem::class.java)
                val item = adapter.fromJson(body) ?: return@withContext Result.failure(Exception("Invalid file format"))
                if (item.content != null) {
                    val rawClean = item.content.replace("\n", "").replace("\r", "")
                    val decoded = Base64.decode(rawClean, Base64.DEFAULT)
                    Result.success(String(decoded, Charsets.UTF_8))
                } else if (item.downloadUrl != null) {
                    // Fallback download directly
                    val dlReq = Request.Builder().url(item.downloadUrl).build()
                    val dlRes = okHttpClient.newCall(dlReq).execute()
                    Result.success(dlRes.body?.string() ?: "")
                } else {
                    Result.failure(Exception("File content not accessible"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun uploadOrUpdateFile(
        owner: String,
        repo: String,
        path: String,
        branch: String,
        message: String,
        rawContent: String,
        sha: String? = null,
        token: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanPath = path.trim().removePrefix("/")
            val url = "https://api.github.com/repos/$owner/$repo/contents/$cleanPath"
            val base64Content = Base64.encodeToString(rawContent.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val payload = GitHubCommitPayload(
                message = message,
                content = base64Content,
                branch = branch,
                sha = sha
            )
            val adapter = moshi.adapter(GitHubCommitPayload::class.java)
            val json = adapter.toJson(payload)
            val request = buildRequest(url, token)
                .put(json.toRequestBody(jsonMediaType))
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Commit failed: HTTP ${response.code}"))
            }
            val rawUrl = toRawUrl(owner, repo, branch, cleanPath)
            Result.success(rawUrl)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteFile(
        owner: String,
        repo: String,
        path: String,
        branch: String,
        sha: String,
        message: String,
        token: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val cleanPath = path.trim().removePrefix("/")
            val url = "https://api.github.com/repos/$owner/$repo/contents/$cleanPath"
            val payload = GitHubDeletePayload(
                message = message,
                sha = sha,
                branch = branch
            )
            val adapter = moshi.adapter(GitHubDeletePayload::class.java)
            val json = adapter.toJson(payload)
            val request = buildRequest(url, token)
                .delete(json.toRequestBody(jsonMediaType))
                .build()

            val response = okHttpClient.newCall(request).execute()
            Result.success(response.isSuccessful)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        fun toRawUrl(owner: String, repo: String, branch: String, path: String): String {
            val cleanPath = path.trim().removePrefix("/")
            return "https://raw.githubusercontent.com/$owner/$repo/$branch/$cleanPath"
        }

        fun parseGitHubBlobToRaw(url: String): String? {
            val trimmed = url.trim()
            // e.g. https://github.com/owner/repo/blob/main/playlist.m3u
            val regex = Regex("https?://github\\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.*)")
            val match = regex.find(trimmed)
            if (match != null) {
                val owner = match.groupValues[1]
                val repo = match.groupValues[2]
                val branch = match.groupValues[3]
                val path = match.groupValues[4]
                return "https://raw.githubusercontent.com/$owner/$repo/$branch/$path"
            }
            if (trimmed.startsWith("https://raw.githubusercontent.com/")) {
                return trimmed
            }
            return null
        }
    }
}
