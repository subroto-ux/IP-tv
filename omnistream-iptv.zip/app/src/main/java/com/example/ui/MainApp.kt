package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.AddEpgDialog
import com.example.ui.components.AddPlaylistDialog
import com.example.ui.components.AddXtreamDialog
import com.example.ui.navigation.Screen
import com.example.ui.screens.favorites.FavoritesScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.livetv.LiveTvScreen
import com.example.ui.screens.movies.MoviesScreen
import com.example.ui.screens.player.PlayerScreen
import com.example.ui.screens.series.SeriesScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.splash.SetupScreen
import com.example.ui.screens.splash.SplashScreen
import com.example.ui.screens.tools.ToolGitHubScreen
import com.example.ui.screens.tools.ToolJsonViewerScreen
import com.example.ui.screens.tools.ToolM3uParserScreen
import com.example.ui.screens.tools.ToolPlaylistStatsScreen
import com.example.ui.screens.tools.ToolRawUrlGenScreen
import com.example.ui.screens.tools.ToolStreamCheckerScreen
import com.example.ui.screens.tools.ToolsScreen
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.OmniStreamTheme
import com.example.ui.viewmodel.MainViewModel
import java.net.URLDecoder

@Composable
fun MainApp(mainViewModel: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val appSettings by mainViewModel.appSettings.collectAsState()
    val statusMessage by mainViewModel.statusMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Dialog visibility states
    var showAddPlaylistDialog by remember { mutableStateOf(false) }
    var showAddXtreamDialog by remember { mutableStateOf(false) }
    var showAddEpgDialog by remember { mutableStateOf(false) }

    // File picker launcher for M3U/M3U8 local files
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            mainViewModel.addPlaylistFromUri(uri, "Imported Playlist")
        }
    }

    LaunchedEffect(statusMessage) {
        if (statusMessage != null) {
            snackbarHostState.showSnackbar(statusMessage!!)
            mainViewModel.clearStatusMessage()
        }
    }

    val themeMode = appSettings?.themeMode ?: "AMOLED"

    OmniStreamTheme(themeMode = themeMode) {
        val showBottomBar = currentRoute in listOf(
            Screen.Home.route,
            Screen.LiveTv.route,
            Screen.Movies.route,
            Screen.Series.route,
            Screen.Favorites.route,
            Screen.Tools.route,
            Screen.Settings.route
        )

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        val items = listOf(
                            NavigationItem(Screen.Home.route, "Home", Icons.Default.Home),
                            NavigationItem(Screen.LiveTv.route, "Live TV", Icons.Default.LiveTv),
                            NavigationItem(Screen.Movies.route, "Movies", Icons.Default.Movie),
                            NavigationItem(Screen.Series.route, "Series", Icons.Default.VideoLibrary),
                            NavigationItem(Screen.Favorites.route, "Favorites", Icons.Default.Favorite),
                            NavigationItem(Screen.Tools.route, "Tools", Icons.Default.Build),
                            NavigationItem(Screen.Settings.route, "Settings", Icons.Default.Settings)
                        )

                        items.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationBarItem(
                                icon = { Icon(imageVector = item.icon, contentDescription = item.label) },
                                label = { Text(item.label, fontSize = 10.sp, maxLines = 1) },
                                selected = selected,
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ElectricCyan,
                                    selectedTextColor = ElectricCyan,
                                    indicatorColor = ElectricCyan.copy(alpha = 0.15f)
                                ),
                                onClick = {
                                    if (currentRoute != item.route) {
                                        navController.navigate(item.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                modifier = Modifier.testTag("nav_tab_${item.label.lowercase().replace(" ", "_")}")
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Splash.route,
                modifier = Modifier.padding(padding)
            ) {
                // Splash Screen
                composable(Screen.Splash.route) {
                    val isFirstLaunch = appSettings?.firstLaunchCompleted != true
                    SplashScreen(
                        isFirstLaunch = isFirstLaunch,
                        onNavigateNext = { firstLaunch ->
                            if (firstLaunch) {
                                navController.navigate(Screen.Setup.route) {
                                    popUpTo(Screen.Splash.route) { inclusive = true }
                                }
                            } else {
                                navController.navigate(Screen.Home.route) {
                                    popUpTo(Screen.Splash.route) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                // Setup / Welcome Screen
                composable(Screen.Setup.route) {
                    SetupScreen(
                        onAddM3uClick = { showAddPlaylistDialog = true },
                        onImportFileClick = { filePickerLauncher.launch("*/*") },
                        onAddXtreamClick = { showAddXtreamDialog = true },
                        onAddEpgClick = { showAddEpgDialog = true },
                        onContinueWithoutSource = {
                            mainViewModel.completeFirstLaunch()
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Setup.route) { inclusive = true }
                            }
                        }
                    )
                }

                // Home Screen
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = mainViewModel,
                        onOpenPlayer = { url, title, type, logo, id, tvg ->
                            navController.navigate(Screen.Player.createRoute(url, title, type, logo, id, tvg))
                        },
                        onNavigateToLiveTv = { navController.navigate(Screen.LiveTv.route) },
                        onNavigateToMovies = { navController.navigate(Screen.Movies.route) },
                        onNavigateToSeries = { navController.navigate(Screen.Series.route) },
                        onNavigateToTools = { navController.navigate(Screen.Tools.route) },
                        onNavigateToSettings = { navController.navigate(Screen.Settings.route) },
                        onAddPlaylistClick = { showAddPlaylistDialog = true },
                        onAddXtreamClick = { showAddXtreamDialog = true },
                        onImportFileClick = { filePickerLauncher.launch("*/*") },
                        onOpenGitHubTool = { navController.navigate(Screen.ToolGitHub.route) },
                        onOpenStreamChecker = { navController.navigate(Screen.ToolStreamChecker.route) },
                        onOpenEpgTool = { showAddEpgDialog = true }
                    )
                }

                // Live TV Screen
                composable(Screen.LiveTv.route) {
                    LiveTvScreen(
                        viewModel = mainViewModel,
                        onOpenPlayer = { url, title, type, logo, id, tvg ->
                            navController.navigate(Screen.Player.createRoute(url, title, type, logo, id, tvg))
                        },
                        onAddPlaylistClick = { showAddPlaylistDialog = true }
                    )
                }

                // Movies Screen
                composable(Screen.Movies.route) {
                    MoviesScreen(
                        viewModel = mainViewModel,
                        onOpenPlayer = { url, title, type, logo, id, tvg ->
                            navController.navigate(Screen.Player.createRoute(url, title, type, logo, id, tvg))
                        },
                        onAddPlaylistClick = { showAddPlaylistDialog = true }
                    )
                }

                // Series Screen
                composable(Screen.Series.route) {
                    SeriesScreen(
                        viewModel = mainViewModel,
                        onOpenSeries = { /* Series episodes detail */ },
                        onAddXtreamClick = { showAddXtreamDialog = true }
                    )
                }

                // Favorites Screen
                composable(Screen.Favorites.route) {
                    FavoritesScreen(
                        viewModel = mainViewModel,
                        onOpenPlayer = { url, title, type, logo, id, tvg ->
                            navController.navigate(Screen.Player.createRoute(url, title, type, logo, id, tvg))
                        }
                    )
                }

                // Tools Screen
                composable(Screen.Tools.route) {
                    ToolsScreen(
                        onOpenM3uParser = { navController.navigate(Screen.ToolM3uParser.route) },
                        onOpenStreamChecker = { navController.navigate(Screen.ToolStreamChecker.route) },
                        onOpenEpgValidator = { showAddEpgDialog = true },
                        onOpenGitHubTool = { navController.navigate(Screen.ToolGitHub.route) },
                        onOpenRawUrlGen = { navController.navigate(Screen.ToolRawUrlGen.route) },
                        onOpenJsonViewer = { navController.navigate(Screen.ToolJsonViewer.route) },
                        onOpenPlaylistStats = { navController.navigate(Screen.ToolPlaylistStats.route) }
                    )
                }

                // Sub-Tool: M3U Parser
                composable(Screen.ToolM3uParser.route) {
                    ToolM3uParserScreen(
                        viewModel = mainViewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                // Sub-Tool: Stream Checker
                composable(Screen.ToolStreamChecker.route) {
                    ToolStreamCheckerScreen(
                        viewModel = mainViewModel,
                        onBack = { navController.popBackStack() },
                        onPlayUrl = { url ->
                            navController.navigate(Screen.Player.createRoute(url, "Checked Stream", "CHANNEL", null, 0L, null))
                        }
                    )
                }

                // Sub-Tool: GitHub Tool
                composable(Screen.ToolGitHub.route) {
                    ToolGitHubScreen(
                        viewModel = mainViewModel,
                        onBack = { navController.popBackStack() },
                        onImportPlaylistUrl = { name, url ->
                            mainViewModel.addPlaylistUrl(name, url)
                            navController.navigate(Screen.LiveTv.route)
                        }
                    )
                }

                // Sub-Tool: Raw URL Generator
                composable(Screen.ToolRawUrlGen.route) {
                    ToolRawUrlGenScreen(
                        onBack = { navController.popBackStack() },
                        onImportPlaylistUrl = { name, url ->
                            mainViewModel.addPlaylistUrl(name, url)
                            navController.navigate(Screen.LiveTv.route)
                        }
                    )
                }

                // Sub-Tool: JSON Viewer
                composable(Screen.ToolJsonViewer.route) {
                    ToolJsonViewerScreen(
                        onBack = { navController.popBackStack() }
                    )
                }

                // Sub-Tool: Playlist Stats
                composable(Screen.ToolPlaylistStats.route) {
                    ToolPlaylistStatsScreen(
                        viewModel = mainViewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                // Settings Screen
                composable(Screen.Settings.route) {
                    SettingsScreen(
                        viewModel = mainViewModel,
                        onAddPlaylistClick = { showAddPlaylistDialog = true },
                        onAddXtreamClick = { showAddXtreamDialog = true },
                        onAddEpgClick = { showAddEpgDialog = true },
                        onBack = null
                    )
                }

                // Player Screen
                composable(
                    route = Screen.Player.route,
                    arguments = listOf(
                        navArgument("streamUrl") { type = NavType.StringType },
                        navArgument("title") { type = NavType.StringType },
                        navArgument("contentType") { type = NavType.StringType },
                        navArgument("logo") { type = NavType.StringType },
                        navArgument("contentId") { type = NavType.LongType },
                        navArgument("tvgId") { type = NavType.StringType }
                    )
                ) { backStackEntry ->
                    val encodedUrl = backStackEntry.arguments?.getString("streamUrl") ?: ""
                    val encodedTitle = backStackEntry.arguments?.getString("title") ?: ""
                    val encodedType = backStackEntry.arguments?.getString("contentType") ?: "CHANNEL"
                    val encodedLogo = backStackEntry.arguments?.getString("logo") ?: "none"
                    val contentId = backStackEntry.arguments?.getLong("contentId") ?: 0L
                    val encodedTvg = backStackEntry.arguments?.getString("tvgId") ?: "none"

                    val streamUrl = URLDecoder.decode(encodedUrl, "UTF-8")
                    val title = URLDecoder.decode(encodedTitle, "UTF-8")
                    val contentType = URLDecoder.decode(encodedType, "UTF-8")
                    val logo = URLDecoder.decode(encodedLogo, "UTF-8")
                    val tvgId = URLDecoder.decode(encodedTvg, "UTF-8")

                    PlayerScreen(
                        viewModel = mainViewModel,
                        streamUrl = streamUrl,
                        title = title,
                        contentType = contentType,
                        logo = if (logo == "none") null else logo,
                        contentId = contentId,
                        tvgId = if (tvgId == "none") null else tvgId,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }

        // Global Dialogs
        if (showAddPlaylistDialog) {
            AddPlaylistDialog(
                onDismiss = { showAddPlaylistDialog = false },
                onConfirm = { name, url, ua, ref ->
                    mainViewModel.addPlaylistUrl(name, url, ua, ref)
                },
                onImportFileClick = {
                    showAddPlaylistDialog = false
                    filePickerLauncher.launch("*/*")
                }
            )
        }

        if (showAddXtreamDialog) {
            AddXtreamDialog(
                onDismiss = { showAddXtreamDialog = false },
                onTest = { server, user, pass ->
                    val res = mainViewModel.testXtreamConnection(server, user, pass)
                    res.isSuccess
                },
                onConfirm = { name, server, user, pass ->
                    mainViewModel.addXtreamAccount(name, server, user, pass)
                }
            )
        }

        if (showAddEpgDialog) {
            AddEpgDialog(
                onDismiss = { showAddEpgDialog = false },
                onConfirm = { name, url ->
                    mainViewModel.addEpgSource(name, url)
                }
            )
        }
    }
}

private data class NavigationItem(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
