package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.database.entity.ChannelEntity
import com.example.data.database.entity.FavoriteEntity
import com.example.data.database.entity.MovieEntity
import com.example.data.database.entity.WatchHistoryEntity
import com.example.ui.components.QuickActionChip
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.RoyalIndigo
import com.example.ui.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onOpenPlayer: (streamUrl: String, title: String, contentType: String, logo: String?, contentId: Long, tvgId: String?) -> Unit,
    onNavigateToLiveTv: () -> Unit,
    onNavigateToMovies: () -> Unit,
    onNavigateToSeries: () -> Unit,
    onNavigateToTools: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onAddPlaylistClick: () -> Unit,
    onAddXtreamClick: () -> Unit,
    onImportFileClick: () -> Unit,
    onOpenGitHubTool: () -> Unit,
    onOpenStreamChecker: () -> Unit,
    onOpenEpgTool: () -> Unit
) {
    val continueWatching by viewModel.continueWatching.collectAsState()
    val recentHistory by viewModel.recentHistory.collectAsState()
    val favorites by viewModel.allFavorites.collectAsState()
    val channels by viewModel.activeChannels.collectAsState()
    val movies by viewModel.activeMovies.collectAsState()
    val series by viewModel.activeSeries.collectAsState()

    var searchQuery by remember { mutableStateOf("") }

    val hasData = channels.isNotEmpty() || movies.isNotEmpty() || series.isNotEmpty() || continueWatching.isNotEmpty()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // App Header & Search Bar
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "OmniStream IPTV",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Tool Of India Developer",
                            style = MaterialTheme.typography.bodySmall,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable(onClick = onNavigateToSettings),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Global Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search channels, movies, series...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("global_search_input")
                )
            }
        }

        // Quick Actions Row
        item {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                Text(
                    text = "Quick Actions",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        QuickActionChip(
                            icon = Icons.Default.Add,
                            label = "Add Playlist",
                            onClick = onAddPlaylistClick
                        )
                    }
                    item {
                        QuickActionChip(
                            icon = Icons.Default.Tv,
                            label = "Add Xtream",
                            onClick = onAddXtreamClick
                        )
                    }
                    item {
                        QuickActionChip(
                            icon = Icons.Default.FileOpen,
                            label = "Import File",
                            onClick = onImportFileClick
                        )
                    }
                    item {
                        QuickActionChip(
                            icon = Icons.Default.Speed,
                            label = "Stream Checker",
                            onClick = onOpenStreamChecker
                        )
                    }
                    item {
                        QuickActionChip(
                            icon = Icons.Default.Code,
                            label = "GitHub Tools",
                            onClick = onOpenGitHubTool
                        )
                    }
                    item {
                        QuickActionChip(
                            icon = Icons.Default.Schedule,
                            label = "EPG Guide",
                            onClick = onOpenEpgTool
                        )
                    }
                }
            }
        }

        // If search is active, show search results
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            val matchedChannels = channels.filter { it.name.lowercase().contains(q) || it.category.lowercase().contains(q) }
            val matchedMovies = movies.filter { it.name.lowercase().contains(q) }

            item {
                Text(
                    text = "Search Results (${matchedChannels.size + matchedMovies.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            items(matchedChannels.take(20)) { ch ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clickable {
                            onOpenPlayer(ch.streamUrl, ch.name, "CHANNEL", ch.logo, ch.id, ch.tvgId)
                        },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.LiveTv, contentDescription = null, tint = ElectricCyan)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = ch.name, fontWeight = FontWeight.Bold)
                            Text(text = ch.category, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        } else {
            // Standard Home Sections (only shown when available data exists)

            // 1. Continue Watching
            if (continueWatching.isNotEmpty()) {
                item {
                    SectionHeader(title = "Continue Watching", onSeeAll = null)
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(continueWatching) { item ->
                            ContinueWatchingCard(
                                item = item,
                                onClick = {
                                    onOpenPlayer(
                                        item.streamUrl,
                                        item.title,
                                        item.contentType,
                                        item.logo,
                                        item.contentId,
                                        null
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // 2. Favorite Channels
            val favoriteChannels = favorites.filter { it.contentType == "CHANNEL" }
            if (favoriteChannels.isNotEmpty()) {
                item {
                    SectionHeader(title = "Favorite Channels", onSeeAll = null)
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(favoriteChannels) { fav ->
                            FavoriteCard(
                                fav = fav,
                                onClick = {
                                    onOpenPlayer(
                                        fav.streamUrl,
                                        fav.title,
                                        "CHANNEL",
                                        fav.logo,
                                        fav.contentId,
                                        null
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // 3. Recently Watched
            if (recentHistory.isNotEmpty()) {
                item {
                    SectionHeader(title = "Recently Watched", onSeeAll = null)
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(recentHistory.take(15)) { history ->
                            HistoryCard(
                                history = history,
                                onClick = {
                                    onOpenPlayer(
                                        history.streamUrl,
                                        history.title,
                                        history.contentType,
                                        history.logo,
                                        history.contentId,
                                        null
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // 4. Live TV Showcase
            if (channels.isNotEmpty()) {
                item {
                    SectionHeader(title = "Live TV (${channels.size} channels)", onSeeAll = onNavigateToLiveTv)
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(channels.take(15)) { ch ->
                            ChannelMiniCard(
                                channel = ch,
                                onClick = {
                                    onOpenPlayer(
                                        ch.streamUrl,
                                        ch.name,
                                        "CHANNEL",
                                        ch.logo,
                                        ch.id,
                                        ch.tvgId
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // 5. Movies Showcase
            if (movies.isNotEmpty()) {
                item {
                    SectionHeader(title = "Movies (${movies.size} titles)", onSeeAll = onNavigateToMovies)
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(movies.take(15)) { m ->
                            MovieMiniCard(
                                movie = m,
                                onClick = {
                                    onOpenPlayer(
                                        m.streamUrl,
                                        m.name,
                                        "MOVIE",
                                        m.poster,
                                        m.id,
                                        null
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // If completely empty (no data yet)
            if (!hasData) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .background(MaterialTheme.colorScheme.surface, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LiveTv,
                                        contentDescription = null,
                                        tint = ElectricCyan,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "No Channels Loaded Yet",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Add an M3U playlist, import a local file, or connect your Xtream server using the quick action buttons above to start watching.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, onSeeAll: (() -> Unit)?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        if (onSeeAll != null) {
            TextButton(onClick = onSeeAll) {
                Text("See All", color = ElectricCyan, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ContinueWatchingCard(item: WatchHistoryEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(170.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(95.dp)
                    .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                if (!item.logo.isNullOrBlank()) {
                    AsyncImage(
                        model = item.logo,
                        contentDescription = item.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = ElectricCyan)
                }
            }
            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.contentType,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun FavoriteCard(fav: FavoriteEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(140.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                if (!fav.logo.isNullOrBlank()) {
                    AsyncImage(model = fav.logo, contentDescription = fav.title, modifier = Modifier.size(40.dp))
                } else {
                    Icon(imageVector = Icons.Default.LiveTv, contentDescription = null, tint = ElectricCyan)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = fav.title,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun HistoryCard(history: WatchHistoryEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(140.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                if (!history.logo.isNullOrBlank()) {
                    AsyncImage(model = history.logo, contentDescription = history.title, modifier = Modifier.size(40.dp))
                } else {
                    Icon(imageVector = Icons.Default.LiveTv, contentDescription = null, tint = ElectricCyan)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = history.title,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ChannelMiniCard(channel: ChannelEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(130.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                if (!channel.logo.isNullOrBlank()) {
                    AsyncImage(model = channel.logo, contentDescription = channel.name, modifier = Modifier.size(38.dp))
                } else {
                    Icon(imageVector = Icons.Default.LiveTv, contentDescription = null, tint = ElectricCyan)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = channel.name,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MovieMiniCard(movie: MovieEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(115.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                if (!movie.poster.isNullOrBlank()) {
                    AsyncImage(
                        model = movie.poster,
                        contentDescription = movie.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(imageVector = Icons.Default.Movie, contentDescription = null, tint = ElectricCyan)
                }
            }
            Text(
                text = movie.name,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(6.dp)
            )
        }
    }
}
