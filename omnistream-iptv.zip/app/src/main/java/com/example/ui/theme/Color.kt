package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Accent Colors
val ElectricCyan = Color(0xFF06B6D4)
val NeonSky = Color(0xFF38BDF8)
val RoyalIndigo = Color(0xFF6366F1)
val VividViolet = Color(0xFF8B5CF6)
val EmeraldGreen = Color(0xFF10B981)
val CoralRed = Color(0xFFEF4444)
val AmberOrange = Color(0xFFF59E0B)

// Dark / Slate Theme
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

// AMOLED Theme (True Black)
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF080C14)
val AmoledSurfaceVariant = Color(0xFF101726)
val AmoledBorder = Color(0xFF1F293D)

// Light Theme
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)
