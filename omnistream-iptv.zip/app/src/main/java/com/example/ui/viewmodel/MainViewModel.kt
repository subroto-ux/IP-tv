package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.entity.AppSettingsEntity
import com.example.data.database.entity.ChannelEntity
import com.example.data.database.entity.EpgProgramEntity
import com.example.data.database.entity.EpgSourceEntity
import com.example.data.database.entity.FavoriteEntity
import com.example.data.database.entity.MovieEntity
import com.example.data.database.entity.PlaylistEntity
import com.example.data.database.entity.SeriesEntity
import com.example.data.database.entity.WatchHistoryEntity
import com.example.data.database.entity.XtreamAccountEntity
import com.example.data.network.StreamCheckResult
import com.example.data.network.XtreamAuthResponse
import com.example.data.repository.IptvRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.InputStream

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: IptvRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = IptvRepository(db, application)
    }

    // Repository Flows
    val allPlaylists: StateFlow<List<PlaylistEntity>> = repository.allPlaylists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activePlaylists: StateFlow<List<PlaylistEntity>> = repository.activePlaylists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeChannels: StateFlow<List<ChannelEntity>> = repository.activeChannels
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<String>> = repository.categories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val countries: StateFlow<List<String>> = repository.countries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val languages: StateFlow<List<String>> = repository.languages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeMovies: StateFlow<List<MovieEntity>> = repository.activeMovies
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val movieCategories: StateFlow<List<String>> = repository.movieCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeSeries: StateFlow<List<SeriesEntity>> = repository.activeSeries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val seriesCategories: StateFlow<List<String>> = repository.seriesCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFavorites: StateFlow<List<FavoriteEntity>> = repository.allFavorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentHistory: StateFlow<List<WatchHistoryEntity>> = repository.recentHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val continueWatching: StateFlow<List<WatchHistoryEntity>> = repository.continueWatching
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allXtreamAccounts: StateFlow<List<XtreamAccountEntity>> = repository.allXtreamAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allEpgSources: StateFlow<List<EpgSourceEntity>> = repository.allEpgSources
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val appSettings: StateFlow<AppSettingsEntity?> = repository.appSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // UI Filter & Search States
    val channelSearchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("All")
    val selectedCountry = MutableStateFlow("All")
    val selectedLanguage = MutableStateFlow("All")
    val channelSortOrder = MutableStateFlow("DEFAULT") // "DEFAULT", "A_Z", "Z_A"

    val movieSearchQuery = MutableStateFlow("")
    val selectedMovieCategory = MutableStateFlow("All")

    val seriesSearchQuery = MutableStateFlow("")
    val selectedSeriesCategory = MutableStateFlow("All")

    // Operation status & loading
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    // Filtered Channels
    private data class ChannelFilterState(
        val query: String,
        val cat: String,
        val country: String,
        val lang: String,
        val sort: String
    )

    private val channelFilters = combine(
        channelSearchQuery,
        selectedCategory,
        selectedCountry,
        selectedLanguage,
        channelSortOrder
    ) { query, cat, country, lang, sort ->
        ChannelFilterState(query, cat, country, lang, sort)
    }

    val filteredChannels: StateFlow<List<ChannelEntity>> = combine(
        activeChannels,
        channelFilters
    ) { channels, filters ->
        var list = channels

        if (filters.cat != "All") {
            list = list.filter { it.category.equals(filters.cat, ignoreCase = true) }
        }
        if (filters.country != "All") {
            list = list.filter { it.country.equals(filters.country, ignoreCase = true) }
        }
        if (filters.lang != "All") {
            list = list.filter { it.language.equals(filters.lang, ignoreCase = true) }
        }
        if (filters.query.isNotBlank()) {
            val q = filters.query.trim().lowercase()
            list = list.filter { it.name.lowercase().contains(q) || it.category.lowercase().contains(q) }
        }

        when (filters.sort) {
            "A_Z" -> list.sortedBy { it.name.lowercase() }
            "Z_A" -> list.sortedByDescending { it.name.lowercase() }
            else -> list
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Movies
    val filteredMovies: StateFlow<List<MovieEntity>> = combine(
        activeMovies,
        movieSearchQuery,
        selectedMovieCategory
    ) { movies, query, cat ->
        var list = movies
        if (cat != "All") {
            list = list.filter { it.category.equals(cat, ignoreCase = true) }
        }
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter { it.name.lowercase().contains(q) }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Series
    val filteredSeries: StateFlow<List<SeriesEntity>> = combine(
        activeSeries,
        seriesSearchQuery,
        selectedSeriesCategory
    ) { series, query, cat ->
        var list = series
        if (cat != "All") {
            list = list.filter { it.category.equals(cat, ignoreCase = true) }
        }
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter { it.name.lowercase().contains(q) }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Actions
    fun addPlaylistUrl(name: String, url: String, userAgent: String? = null, referer: String? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            _statusMessage.value = "Downloading and parsing playlist..."
            val result = repository.addPlaylistFromUrl(name, url, userAgent, referer)
            _isLoading.value = false
            if (result.isSuccess) {
                val p = result.getOrNull()
                _statusMessage.value = "Added ${p?.channelCount ?: 0} channels successfully!"
            } else {
                _statusMessage.value = "Error: ${result.exceptionOrNull()?.message ?: "Failed to add playlist"}"
            }
        }
    }

    fun addPlaylistFromUri(uri: Uri, name: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _statusMessage.value = "Reading local playlist file..."
            try {
                val inputStream: InputStream? = getApplication<Application>().contentResolver.openInputStream(uri)
                if (inputStream != null) {
                    val result = repository.addPlaylistFromStream(name, inputStream)
                    _isLoading.value = false
                    if (result.isSuccess) {
                        val p = result.getOrNull()
                        _statusMessage.value = "Imported ${p?.channelCount ?: 0} channels from file!"
                    } else {
                        _statusMessage.value = "Import error: ${result.exceptionOrNull()?.message}"
                    }
                } else {
                    _isLoading.value = false
                    _statusMessage.value = "Could not open selected file"
                }
            } catch (e: Exception) {
                _isLoading.value = false
                _statusMessage.value = "Error: ${e.message}"
            }
        }
    }

    fun refreshPlaylist(playlistId: Long) {
        viewModelScope.launch {
            _isLoading.value = true
            _statusMessage.value = "Refreshing playlist..."
            val result = repository.refreshPlaylist(playlistId)
            _isLoading.value = false
            if (result.isSuccess) {
                _statusMessage.value = "Refreshed! Found ${result.getOrNull()} channels."
            } else {
                _statusMessage.value = "Refresh error: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun togglePlaylistActive(id: Long, isActive: Boolean) {
        viewModelScope.launch {
            repository.setPlaylistActive(id, isActive)
        }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(id)
            _statusMessage.value = "Playlist deleted"
        }
    }

    fun toggleChannelFavorite(channel: ChannelEntity) {
        viewModelScope.launch {
            repository.toggleChannelFavorite(channel)
        }
    }

    fun toggleMovieFavorite(movie: MovieEntity) {
        viewModelScope.launch {
            repository.toggleMovieFavorite(movie)
        }
    }

    fun recordWatchProgress(
        contentId: Long,
        contentType: String,
        title: String,
        streamUrl: String,
        logo: String?,
        playlistName: String?,
        positionMs: Long,
        durationMs: Long
    ) {
        viewModelScope.launch {
            repository.recordWatchProgress(
                contentId,
                contentType,
                title,
                streamUrl,
                logo,
                playlistName,
                positionMs,
                durationMs
            )
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.deleteHistoryItem(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
            _statusMessage.value = "Watch history cleared"
        }
    }

    // Xtream
    fun addXtreamAccount(name: String, server: String, user: String, pass: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _statusMessage.value = "Connecting to Xtream server..."
            val result = repository.addXtreamAccount(name, server, user, pass)
            _isLoading.value = false
            if (result.isSuccess) {
                _statusMessage.value = "Xtream account added and synced!"
            } else {
                _statusMessage.value = "Xtream login failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    suspend fun testXtreamConnection(server: String, user: String, pass: String): Result<XtreamAuthResponse> {
        return repository.testXtreamConnection(server, user, pass)
    }

    fun deleteXtreamAccount(id: Long) {
        viewModelScope.launch {
            repository.deleteXtreamAccount(id)
            _statusMessage.value = "Xtream account removed"
        }
    }

    // EPG
    fun addEpgSource(name: String, url: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _statusMessage.value = "Adding EPG source..."
            val result = repository.addEpgSource(name, url)
            _isLoading.value = false
            if (result.isSuccess) {
                _statusMessage.value = "EPG source added!"
            } else {
                _statusMessage.value = "EPG error: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun refreshEpg(id: Long) {
        viewModelScope.launch {
            _isLoading.value = true
            _statusMessage.value = "Updating EPG..."
            val result = repository.refreshEpgSource(id)
            _isLoading.value = false
            if (result.isSuccess) {
                _statusMessage.value = "EPG updated with ${result.getOrNull()} programs"
            } else {
                _statusMessage.value = "EPG update failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    suspend fun getChannelCurrentProgram(tvgId: String?): EpgProgramEntity? {
        if (tvgId.isNullOrBlank()) return null
        return repository.getCurrentProgram(tvgId)
    }

    suspend fun getChannelUpcomingPrograms(tvgId: String?): List<EpgProgramEntity> {
        if (tvgId.isNullOrBlank()) return emptyList()
        return repository.getUpcomingPrograms(tvgId)
    }

    // Settings
    fun updateTheme(themeMode: String) {
        viewModelScope.launch {
            val current = repository.getSettings()
            repository.updateSettings(current.copy(themeMode = themeMode))
        }
    }

    fun updateSetting(
        autoRotate: Boolean? = null,
        keepScreenOn: Boolean? = null,
        autoReconnect: Boolean? = null,
        aspectRatio: String? = null,
        defaultPlayer: String? = null,
        removeDuplicates: Boolean? = null
    ) {
        viewModelScope.launch {
            val current = repository.getSettings()
            val updated = current.copy(
                autoRotate = autoRotate ?: current.autoRotate,
                keepScreenOn = keepScreenOn ?: current.keepScreenOn,
                autoReconnect = autoReconnect ?: current.autoReconnect,
                defaultAspectRatio = aspectRatio ?: current.defaultAspectRatio,
                defaultPlayer = defaultPlayer ?: current.defaultPlayer,
                removeDuplicates = removeDuplicates ?: current.removeDuplicates
            )
            repository.updateSettings(updated)
        }
    }

    fun completeFirstLaunch() {
        viewModelScope.launch {
            val current = repository.getSettings()
            repository.updateSettings(current.copy(firstLaunchCompleted = true))
        }
    }

    // Stream Checker Utility
    suspend fun checkStreamUrl(url: String): StreamCheckResult {
        return repository.streamChecker.checkStream(url)
    }

    fun parseM3uRaw(rawContent: String) = repository.parseM3uRaw(rawContent)
}
