package com.example.ui.navigation

import java.net.URLDecoder
import java.net.URLEncoder

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Setup : Screen("setup")
    object Home : Screen("home")
    object LiveTv : Screen("livetv")
    object Movies : Screen("movies")
    object Series : Screen("series")
    object Favorites : Screen("favorites")
    object Tools : Screen("tools")
    object Settings : Screen("settings")

    // Sub-screens
    object Player : Screen("player/{streamUrl}/{title}/{contentType}/{logo}/{contentId}/{tvgId}") {
        fun createRoute(
            streamUrl: String,
            title: String,
            contentType: String = "CHANNEL",
            logo: String? = null,
            contentId: Long = 0L,
            tvgId: String? = null
        ): String {
            val encodedUrl = URLEncoder.encode(streamUrl, "UTF-8")
            val encodedTitle = URLEncoder.encode(title, "UTF-8")
            val encodedType = URLEncoder.encode(contentType, "UTF-8")
            val encodedLogo = URLEncoder.encode(logo ?: "none", "UTF-8")
            val encodedTvg = URLEncoder.encode(tvgId ?: "none", "UTF-8")
            return "player/$encodedUrl/$encodedTitle/$encodedType/$encodedLogo/$contentId/$encodedTvg"
        }
    }

    object SeriesDetail : Screen("series_detail/{seriesId}") {
        fun createRoute(seriesId: Long): String = "series_detail/$seriesId"
    }

    // Tools routes
    object ToolM3uParser : Screen("tool_m3u_parser")
    object ToolStreamChecker : Screen("tool_stream_checker")
    object ToolEpgChecker : Screen("tool_epg_checker")
    object ToolGitHub : Screen("tool_github")
    object ToolRawUrlGen : Screen("tool_raw_url_gen")
    object ToolJsonViewer : Screen("tool_json_viewer")
    object ToolPlaylistStats : Screen("tool_playlist_stats")
}
