package com.example.ui.screens.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.network.GitHubContentItem
import com.example.data.network.GitHubRepo
import com.example.data.network.GitHubService
import com.example.ui.theme.ElectricCyan
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolGitHubScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onImportPlaylistUrl: (name: String, url: String) -> Unit
) {
    val service = remember { GitHubService() }
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current

    var token by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var repos by remember { mutableStateOf<List<GitHubRepo>>(emptyList()) }
    var selectedRepo by remember { mutableStateOf<GitHubRepo?>(null) }
    var currentPath by remember { mutableStateOf("") }
    var contents by remember { mutableStateOf<List<GitHubContentItem>>(emptyList()) }

    var viewingFile by remember { mutableStateOf<Pair<GitHubContentItem, String>?>(null) }
    var showUploadDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (selectedRepo == null) "GitHub Playlist Tool" else selectedRepo!!.name,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (selectedRepo != null) {
                            if (currentPath.isNotEmpty()) {
                                // Go up one directory
                                val idx = currentPath.lastIndexOf('/')
                                currentPath = if (idx != -1) currentPath.substring(0, idx) else ""
                                scope.launch {
                                    isLoading = true
                                    val res = service.getContents(
                                        selectedRepo!!.fullName.split("/")[0],
                                        selectedRepo!!.name,
                                        currentPath,
                                        selectedRepo!!.defaultBranch,
                                        token.ifBlank { null }
                                    )
                                    isLoading = false
                                    if (res.isSuccess) contents = res.getOrNull() ?: emptyList()
                                }
                            } else {
                                selectedRepo = null
                                contents = emptyList()
                            }
                        } else {
                            onBack()
                        }
                    }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (selectedRepo == null) {
                // Config & Connect
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("GitHub Connection", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            OutlinedTextField(
                                value = username,
                                onValueChange = { username = it },
                                label = { Text("Username / Organization") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = token,
                                onValueChange = { token = it },
                                label = { Text("Personal Access Token (Optional for public repos)") },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = {
                                    scope.launch {
                                        isLoading = true
                                        errorMessage = null
                                        val res = service.getRepositories(username.ifBlank { null }, token.ifBlank { null })
                                        isLoading = false
                                        if (res.isSuccess) {
                                            repos = res.getOrNull() ?: emptyList()
                                        } else {
                                            errorMessage = res.exceptionOrNull()?.message
                                        }
                                    }
                                },
                                enabled = (username.isNotBlank() || token.isNotBlank()) && !isLoading,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                                } else {
                                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Load Repositories")
                                }
                            }
                        }
                    }
                }

                if (errorMessage != null) {
                    item {
                        Text(text = errorMessage!!, color = Color(0xFFEF4444), fontSize = 13.sp)
                    }
                }

                if (repos.isNotEmpty()) {
                    item {
                        Text("Repositories (${repos.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    }

                    items(repos) { repo ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedRepo = repo
                                    currentPath = ""
                                    scope.launch {
                                        isLoading = true
                                        val parts = repo.fullName.split("/")
                                        val owner = parts[0]
                                        val res = service.getContents(owner, repo.name, "", repo.defaultBranch, token.ifBlank { null })
                                        isLoading = false
                                        if (res.isSuccess) contents = res.getOrNull() ?: emptyList()
                                    }
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = ElectricCyan)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(repo.fullName, fontWeight = FontWeight.Bold)
                                    Text(repo.description ?: "Default branch: ${repo.defaultBranch}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null)
                            }
                        }
                    }
                }
            } else {
                // Repo File Explorer
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "/${currentPath.ifEmpty { "(root)" }}",
                            fontWeight = FontWeight.Bold,
                            color = ElectricCyan,
                            fontSize = 14.sp
                        )
                        if (token.isNotBlank()) {
                            OutlinedButton(onClick = { showUploadDialog = true }) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New File")
                            }
                        }
                    }
                }

                if (isLoading) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = ElectricCyan)
                        }
                    }
                } else {
                    items(contents) { item ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (item.type == "dir") {
                                        currentPath = item.path
                                        scope.launch {
                                            isLoading = true
                                            val parts = selectedRepo!!.fullName.split("/")
                                            val res = service.getContents(parts[0], selectedRepo!!.name, item.path, selectedRepo!!.defaultBranch, token.ifBlank { null })
                                            isLoading = false
                                            if (res.isSuccess) contents = res.getOrNull() ?: emptyList()
                                        }
                                    } else {
                                        // Fetch file content
                                        scope.launch {
                                            isLoading = true
                                            val parts = selectedRepo!!.fullName.split("/")
                                            val fileRes = service.getFileContent(parts[0], selectedRepo!!.name, item.path, selectedRepo!!.defaultBranch, token.ifBlank { null })
                                            isLoading = false
                                            if (fileRes.isSuccess) {
                                                viewingFile = Pair(item, fileRes.getOrNull() ?: "")
                                            }
                                        }
                                    }
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (item.type == "dir") Icons.Default.Folder else Icons.Default.Description,
                                    contentDescription = null,
                                    tint = if (item.type == "dir") Color(0xFFF59E0B) else ElectricCyan
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        if (item.type == "dir") "Folder" else "${item.size} bytes",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (item.name.endsWith(".m3u", ignoreCase = true) || item.name.endsWith(".m3u8", ignoreCase = true)) {
                                    val parts = selectedRepo!!.fullName.split("/")
                                    val rawUrl = GitHubService.toRawUrl(parts[0], selectedRepo!!.name, selectedRepo!!.defaultBranch, item.path)
                                    Button(
                                        onClick = {
                                            onImportPlaylistUrl(item.name, rawUrl)
                                        },
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Text("Import M3U", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // View / Edit / Copy Raw Dialog
    if (viewingFile != null) {
        val (item, content) = viewingFile!!
        val parts = selectedRepo?.fullName?.split("/") ?: listOf("", "")
        val rawUrl = GitHubService.toRawUrl(parts[0], selectedRepo?.name ?: "", selectedRepo?.defaultBranch ?: "main", item.path)

        AlertDialog(
            onDismissRequest = { viewingFile = null },
            title = { Text(item.name, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Raw Direct Link:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(rawUrl, fontSize = 12.sp, color = ElectricCyan)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            clipboardManager.setText(AnnotatedString(rawUrl))
                        }) {
                            Text("Copy Raw URL")
                        }

                        if (item.name.endsWith(".m3u", true) || item.name.endsWith(".m3u8", true)) {
                            Button(onClick = {
                                onImportPlaylistUrl(item.name, rawUrl)
                                viewingFile = null
                            }) {
                                Text("Import Playlist")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Content Preview:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = content.take(3000),
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().height(180.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewingFile = null }) { Text("Close") }
            }
        )
    }

    // Upload / Create Dialog
    if (showUploadDialog && selectedRepo != null) {
        var newFileName by remember { mutableStateOf("playlist.m3u") }
        var newFileContent by remember { mutableStateOf("#EXTM3U\n#EXTINF:-1,Channel 1\nhttp://example.com/live.m3u8") }
        var commitMsg by remember { mutableStateOf("Add IPTV playlist via OmniStream") }

        AlertDialog(
            onDismissRequest = { showUploadDialog = false },
            title = { Text("Create File on GitHub", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newFileName,
                        onValueChange = { newFileName = it },
                        label = { Text("File Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = commitMsg,
                        onValueChange = { commitMsg = it },
                        label = { Text("Commit Message") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newFileContent,
                        onValueChange = { newFileContent = it },
                        label = { Text("File Content") },
                        modifier = Modifier.fillMaxWidth().height(140.dp)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val parts = selectedRepo!!.fullName.split("/")
                    val fullPath = if (currentPath.isEmpty()) newFileName else "$currentPath/$newFileName"
                    scope.launch {
                        isLoading = true
                        val res = service.uploadOrUpdateFile(
                            owner = parts[0],
                            repo = selectedRepo!!.name,
                            path = fullPath,
                            branch = selectedRepo!!.defaultBranch,
                            message = commitMsg,
                            rawContent = newFileContent,
                            token = token
                        )
                        showUploadDialog = false
                        // Refresh contents
                        val refreshRes = service.getContents(parts[0], selectedRepo!!.name, currentPath, selectedRepo!!.defaultBranch, token)
                        isLoading = false
                        if (refreshRes.isSuccess) contents = refreshRes.getOrNull() ?: emptyList()
                    }
                }) {
                    Text("Commit & Upload")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUploadDialog = false }) { Text("Cancel") }
            }
        )
    }
}
