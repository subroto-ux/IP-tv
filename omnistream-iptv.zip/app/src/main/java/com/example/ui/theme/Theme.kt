package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AmoledColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = Color.Black,
    primaryContainer = RoyalIndigo,
    onPrimaryContainer = Color.White,
    secondary = NeonSky,
    onSecondary = Color.Black,
    tertiary = VividViolet,
    background = AmoledBackground,
    onBackground = TextPrimaryDark,
    surface = AmoledSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = AmoledSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = AmoledBorder,
    error = CoralRed
)

private val DarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = Color.Black,
    primaryContainer = RoyalIndigo,
    onPrimaryContainer = Color.White,
    secondary = NeonSky,
    onSecondary = Color.Black,
    tertiary = VividViolet,
    background = DarkBackground,
    onBackground = TextPrimaryDark,
    surface = DarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = DarkBorder,
    error = CoralRed
)

private val LightColorScheme = lightColorScheme(
    primary = RoyalIndigo,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E7FF),
    onPrimaryContainer = RoyalIndigo,
    secondary = ElectricCyan,
    onSecondary = Color.White,
    tertiary = VividViolet,
    background = LightBackground,
    onBackground = TextPrimaryLight,
    surface = LightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = LightBorder,
    error = CoralRed
)

@Composable
fun OmniStreamTheme(
    themeMode: String = "AMOLED", // "AMOLED", "DARK", "LIGHT"
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode.uppercase()) {
        "LIGHT" -> LightColorScheme
        "DARK" -> DarkColorScheme
        else -> AmoledColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
