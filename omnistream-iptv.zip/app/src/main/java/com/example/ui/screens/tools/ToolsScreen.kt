package com.example.ui.screens.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DataArray
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NeonSky
import com.example.ui.theme.RoyalIndigo
import com.example.ui.theme.VividViolet

@Composable
fun ToolsScreen(
    onOpenM3uParser: () -> Unit,
    onOpenStreamChecker: () -> Unit,
    onOpenEpgValidator: () -> Unit,
    onOpenGitHubTool: () -> Unit,
    onOpenRawUrlGen: () -> Unit,
    onOpenJsonViewer: () -> Unit,
    onOpenPlaylistStats: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(bottom = 8.dp)) {
                Text(
                    text = "IPTV Utilities & Tools",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "High-precision tools for IPTV curation, parsing and diagnostics",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 1. M3U / M3U8 Playlist Parser & Analyzer
        item {
            ToolCard(
                icon = Icons.Default.PlaylistPlay,
                iconColor = ElectricCyan,
                title = "M3U / M3U8 Parser & Analyzer",
                description = "Parse raw playlist text, inspect #EXTINF tags, detect duplicates, categories, and countries",
                onClick = onOpenM3uParser
            )
        }

        // 2. Stream Checker
        item {
            ToolCard(
                icon = Icons.Default.Speed,
                iconColor = EmeraldGreen,
                title = "Stream URL Checker",
                description = "Test stream latency, HTTP status code, media content-type, and playback availability",
                onClick = onOpenStreamChecker
            )
        }

        // 3. GitHub Multi-Tool
        item {
            ToolCard(
                icon = Icons.Default.Code,
                iconColor = RoyalIndigo,
                title = "GitHub Playlist Manager",
                description = "Browse repos, branches, commit/upload M3U files, and convert blob links to raw stream URLs",
                onClick = onOpenGitHubTool
            )
        }

        // 4. Raw GitHub URL Generator
        item {
            ToolCard(
                icon = Icons.Default.Link,
                iconColor = NeonSky,
                title = "GitHub Raw URL Generator",
                description = "Convert github.com blob URLs into direct raw.githubusercontent.com streaming links",
                onClick = onOpenRawUrlGen
            )
        }

        // 5. XMLTV / EPG Validator
        item {
            ToolCard(
                icon = Icons.Default.Schedule,
                iconColor = VividViolet,
                title = "EPG / XMLTV Validator",
                description = "Validate XMLTV program guide structure, channel mapping, and upcoming schedules",
                onClick = onOpenEpgValidator
            )
        }

        // 6. JSON Viewer & Formatter
        item {
            ToolCard(
                icon = Icons.Default.DataObject,
                iconColor = ElectricCyan,
                title = "JSON Viewer & Formatter",
                description = "Pretty-print, validate, format, and inspect Xtream Codes API JSON responses",
                onClick = onOpenJsonViewer
            )
        }

        // 7. Playlist Statistics
        item {
            ToolCard(
                icon = Icons.Default.Analytics,
                iconColor = EmeraldGreen,
                title = "Playlist Statistics",
                description = "Comprehensive breakdown of active channels, categories, duplicate stats, and source health",
                onClick = onOpenPlaylistStats
            )
        }
    }
}

@Composable
private fun ToolCard(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(iconColor.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
